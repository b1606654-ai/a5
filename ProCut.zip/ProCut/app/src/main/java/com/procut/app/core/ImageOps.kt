package com.procut.app.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

data class ImageParams(
    val auto: Boolean = true,
    val autoStrength: Float = 1f,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
    val sharpen: Float = 0.3f,
    val denoise: Float = 0f,
    val filterId: String = "none",
    val filterIntensity: Float = 1f,
    val upscale: Boolean = false
)

/** Pure-Kotlin computational photo enhancement (no network, no model files). */
object ImageOps {

    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val m = max(w, h)
            if (m > maxSide) {
                val f = maxSide.toFloat() / m
                decoder.setTargetSize((w * f).toInt().coerceAtLeast(1), (h * f).toInt().coerceAtLeast(1))
            }
        }.copy(Bitmap.Config.ARGB_8888, true)
    } catch (e: Throwable) {
        null
    }

    fun process(src: Bitmap, p: ImageParams, allowUpscale: Boolean): Bitmap {
        var w = src.width
        var h = src.height
        var px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        if (p.denoise > 0f) denoise(px, w, h, p.denoise)
        if (p.auto) autoLevels(px, p.autoStrength)

        val cm = ColorOps.build(p.brightness, p.contrast, p.saturation, p.warmth, false, p.filterId, p.filterIntensity)
        if (!ColorOps.isIdentity(cm)) applyMatrix(px, cm)
        if (p.sharpen > 0f) px = sharpen(px, w, h, p.sharpen)

        var out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        if (p.upscale && allowUpscale) {
            val big = Bitmap.createScaledBitmap(out, w * 2, h * 2, true)
            w *= 2; h *= 2
            var bp = IntArray(w * h)
            big.getPixels(bp, 0, w, 0, 0, w, h)
            bp = sharpen(bp, w, h, 0.55f)
            out = Bitmap.createBitmap(bp, w, h, Bitmap.Config.ARGB_8888)
        }
        return out
    }

    private fun applyMatrix(px: IntArray, m: FloatArray) {
        for (i in px.indices) {
            val c = px[i]
            val r = ((c shr 16) and 255).toFloat()
            val g = ((c shr 8) and 255).toFloat()
            val b = (c and 255).toFloat()
            val nr = (m[0] * r + m[1] * g + m[2] * b + m[4]).roundToInt().coerceIn(0, 255)
            val ng = (m[5] * r + m[6] * g + m[7] * b + m[9]).roundToInt().coerceIn(0, 255)
            val nb = (m[10] * r + m[11] * g + m[12] * b + m[14]).roundToInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
    }

    /** Histogram stretch + gamma toward mid-grey + mild gray-world white balance. */
    private fun autoLevels(px: IntArray, strength: Float) {
        val total = px.size
        val step = max(1, total / 300_000)
        val lumH = IntArray(256)
        var n = 0
        var sr = 0L; var sg = 0L; var sb = 0L
        var i = 0
        while (i < total) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            lumH[(r * 299 + g * 587 + b * 114) / 1000]++
            sr += r; sg += g; sb += b; n++
            i += step
        }
        if (n == 0) return
        fun pct(q: Float): Int {
            val target = (n * q).toInt()
            var acc = 0
            for (v in 0..255) { acc += lumH[v]; if (acc >= target) return v }
            return 255
        }
        val lo = pct(0.005f).toFloat()
        var hi = pct(0.995f).toFloat()
        if (hi - lo < 32f) hi = lo + 32f
        val mr = sr.toFloat() / n; val mg = sg.toFloat() / n; val mb = sb.toFloat() / n
        val avg = (mr + mg + mb) / 3f
        fun gain(m: Float) = (avg / m.coerceAtLeast(1f)).coerceIn(0.9f, 1.1f)
        val gains = floatArrayOf(gain(mr), gain(mg), gain(mb))
        val meanL = mr * 0.299f + mg * 0.587f + mb * 0.114f
        val m = ((meanL - lo) / (hi - lo)).coerceIn(0.08f, 0.92f)
        val gamma = (ln(0.46f) / ln(m)).coerceIn(0.75f, 1.3f)
        val luts = Array(3) { ch ->
            IntArray(256) { v ->
                val x = ((v * gains[ch] - lo) / (hi - lo)).coerceIn(0f, 1f)
                val y = x.pow(gamma)
                val blended = (v / 255f) * (1f - strength) + y * strength
                (blended * 255f).roundToInt().coerceIn(0, 255)
            }
        }
        for (k in px.indices) {
            val c = px[k]
            px[k] = (0xFF shl 24) or
                (luts[0][(c shr 16) and 255] shl 16) or
                (luts[1][(c shr 8) and 255] shl 8) or
                luts[2][c and 255]
        }
    }

    /** Edge-preserving smoothing: blends toward a 3x3 mean only where the pixel is close to it. */
    private fun denoise(px: IntArray, w: Int, h: Int, s: Float) {
        if (w < 3 || h < 3) return
        val src = px.copyOf()
        val th = 18f + 40f * s
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var sr = 0; var sg = 0; var sb = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val c = src[(y + dy) * w + x + dx]
                    sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                }
                val ar = sr / 9; val ag = sg / 9; val ab = sb / 9
                val c = src[y * w + x]
                val cr = (c shr 16) and 255; val cg = (c shr 8) and 255; val cb = c and 255
                val diff = (abs(cr - ar) + abs(cg - ag) + abs(cb - ab)) / 3f
                val wgt = ((1f - diff / th).coerceIn(0f, 1f)) * s
                val nr = (cr + (ar - cr) * wgt).roundToInt()
                val ng = (cg + (ag - cg) * wgt).roundToInt()
                val nb = (cb + (ab - cb) * wgt).roundToInt()
                px[y * w + x] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
        }
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int): IntArray {
        val tmp = IntArray(px.size)
        val out = IntArray(px.size)
        val n = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) {
                    val c = px[row + (x + k).coerceIn(0, w - 1)]
                    sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                }
                tmp[row + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) {
                    val c = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                    sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                }
                out[y * w + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }
        return out
    }

    /** Unsharp mask. */
    private fun sharpen(px: IntArray, w: Int, h: Int, amount: Float): IntArray {
        val radius = if (w.toLong() * h > 4_000_000L) 2 else 1
        val blur = boxBlur(px, w, h, radius)
        val a = amount * 1.5f
        val out = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]; val b = blur[i]
            val r = ((c shr 16) and 255); val g = ((c shr 8) and 255); val bl = c and 255
            val nr = (r + a * (r - ((b shr 16) and 255))).roundToInt().coerceIn(0, 255)
            val ng = (g + a * (g - ((b shr 8) and 255))).roundToInt().coerceIn(0, 255)
            val nb = (bl + a * (bl - (b and 255))).roundToInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }
}
