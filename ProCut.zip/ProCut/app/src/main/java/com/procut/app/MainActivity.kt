package com.procut.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.procut.app.editor.EditorScreen
import com.procut.app.editor.VideoInfo
import com.procut.app.editor.probeVideo
import com.procut.app.ui.Black
import com.procut.app.ui.HomeScreen
import com.procut.app.ui.ImageScreen
import com.procut.app.ui.PrimaryButton
import com.procut.app.ui.ProCutTheme
import com.procut.app.ui.White
import com.procut.app.util.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.platform.LocalContext

sealed interface Screen {
    data object Home : Screen
    data class Editor(val uri: Uri) : Screen
    data class Photo(val uri: Uri) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ProCutTheme { App() } }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) screen = Screen.Editor(uri)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) screen = Screen.Photo(uri)
    }
    when (val s = screen) {
        Screen.Home -> HomeScreen(
            onVideo = { pickVideo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            onPhoto = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        )
        is Screen.Editor -> EditorLoader(s.uri) { screen = Screen.Home }
        is Screen.Photo -> ImageScreen(s.uri) { screen = Screen.Home }
    }
}

@Composable
private fun EditorLoader(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var info by remember(uri) { mutableStateOf<VideoInfo?>(null) }
    var failed by remember(uri) { mutableStateOf(false) }
    LaunchedEffect(uri) {
        val r = withContext(Dispatchers.IO) { probeVideo(ctx, uri) }
        if (r == null) failed = true else info = r
    }
    BackHandler(onBack = onBack)
    val i = info
    if (i != null) {
        EditorScreen(i, onBack)
    } else {
        Box(Modifier.fillMaxSize().background(Black), contentAlignment = Alignment.Center) {
            if (failed) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(tr("تعذّر فتح الفيديو", "Could not open video"), color = White)
                    PrimaryButton(tr("رجوع", "Back")) { onBack() }
                }
            } else CircularProgressIndicator(color = com.procut.app.ui.Red)
        }
    }
}
