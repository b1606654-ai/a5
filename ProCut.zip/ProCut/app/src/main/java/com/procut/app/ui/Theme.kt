package com.procut.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Red = Color(0xFFE50914)
val RedDark = Color(0xFF9E0710)
val Black = Color(0xFF09090A)
val Surface1 = Color(0xFF141416)
val Surface2 = Color(0xFF212125)
val Muted = Color(0xFF9B9BA3)
val White = Color(0xFFFFFFFF)

@Composable
fun ProCutTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            onPrimary = White,
            secondary = Red,
            background = Black,
            onBackground = White,
            surface = Surface1,
            onSurface = White,
            surfaceVariant = Surface2,
            onSurfaceVariant = Muted,
            surfaceContainer = Surface1,
            surfaceContainerHigh = Surface2,
            outline = Surface2
        ),
        content = content
    )
}
