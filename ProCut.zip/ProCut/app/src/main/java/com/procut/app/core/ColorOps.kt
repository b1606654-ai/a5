package com.procut.app.core

import android.graphics.ColorMatrix
import kotlin.math.abs

class FilterPreset(val id: String, val ar: String, val en: String, val matrix: FloatArray?)

/** 4x5 Android-style colour matrices (row-major, offsets in 0..255). */
object ColorOps {
    val IDENTITY = floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    fun isIdentity(m: FloatArray) = m.indices.all { abs(m[it] - IDENTITY[it]) < 1e-4f }

    /** Apply [first], then [second]. */
    fun concat(first: FloatArray, second: FloatArray): FloatArray {
        val cm = ColorMatrix(first)
        cm.postConcat(ColorMatrix(second))
        return cm.array.copyOf()
    }

    fun chain(vararg ms: FloatArray): FloatArray = ms.fold(IDENTITY) { acc, m -> concat(acc, m) }

    fun lerp(a: FloatArray, b: FloatArray, t: Float) = FloatArray(20) { a[it] + (b[it] - a[it]) * t }

    fun saturation(s: Float): FloatArray {
        val cm = ColorMatrix(); cm.setSaturation(s); return cm.array.copyOf()
    }

    fun contrast(c: Float): FloatArray {
        val t = (-0.5f * c + 0.5f) * 255f
        return floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    }

    fun brightness(b: Float): FloatArray {
        val o = b * 255f
        return floatArrayOf(
            1f, 0f, 0f, 0f, o,
            0f, 1f, 0f, 0f, o,
            0f, 0f, 1f, 0f, o,
            0f, 0f, 0f, 1f, 0f
        )
    }

    fun scale(r: Float, g: Float, b: Float) = floatArrayOf(
        r, 0f, 0f, 0f, 0f,
        0f, g, 0f, 0f, 0f,
        0f, 0f, b, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    private val SEPIA = floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    val FILTERS: List<FilterPreset> = listOf(
        FilterPreset("none", "أصلي", "Original", null),
        FilterPreset("vivid", "نابض", "Vivid", chain(saturation(1.4f), contrast(1.1f))),
        FilterPreset("cine", "سينمائي", "Cinematic", chain(scale(1.08f, 1.0f, 0.92f), saturation(1.1f), contrast(1.12f))),
        FilterPreset("warm", "دافئ", "Warm", scale(1.1f, 1.02f, 0.9f)),
        FilterPreset("cool", "بارد", "Cool", scale(0.92f, 1.0f, 1.1f)),
        FilterPreset("gold", "ذهبي", "Golden", chain(scale(1.12f, 1.04f, 0.85f), saturation(1.1f))),
        FilterPreset("vintage", "كلاسيكي", "Vintage", chain(lerp(IDENTITY, SEPIA, 0.5f), contrast(0.9f), brightness(0.04f))),
        FilterPreset("fade", "باهت", "Fade", chain(contrast(0.85f), brightness(0.06f), saturation(0.85f))),
        FilterPreset("drama", "درامي", "Dramatic", chain(contrast(1.35f), saturation(1.2f), brightness(-0.03f))),
        FilterPreset("sepia", "سيبيا", "Sepia", SEPIA),
        FilterPreset("bw", "أبيض وأسود", "B&W", saturation(0f)),
        FilterPreset("noir", "نوار", "Noir", chain(saturation(0f), contrast(1.35f)))
    )

    fun filterById(id: String): FilterPreset = FILTERS.firstOrNull { it.id == id } ?: FILTERS[0]

    /**
     * All sliders are -1..1. Result is one combined 4x5 matrix.
     */
    fun build(
        bri: Float, con: Float, sat: Float, warm: Float,
        auto: Boolean, filterId: String, filterIntensity: Float
    ): FloatArray {
        var m = IDENTITY
        filterById(filterId).matrix?.let { m = lerp(IDENTITY, it, filterIntensity) }
        if (auto) m = concat(m, chain(contrast(1.08f), saturation(1.12f), brightness(0.02f)))
        if (bri != 0f) m = concat(m, brightness(bri * 0.35f))
        if (con != 0f) m = concat(m, contrast(1f + con * 0.6f))
        if (sat != 0f) m = concat(m, saturation(1f + sat))
        if (warm != 0f) m = concat(m, scale(1f + 0.18f * warm, 1f + 0.02f * warm, 1f - 0.18f * warm))
        return m
    }

    /** Android 4x5 (offsets 0..255) -> 4x4 column-major RGBA matrix for Media3 RgbMatrix. */
    fun toRgb4(cm: FloatArray): FloatArray {
        val out = FloatArray(16)
        for (i in 0..3) {
            for (j in 0..3) out[j * 4 + i] = cm[i * 5 + j]
            out[3 * 4 + i] += cm[i * 5 + 4] / 255f   // offsets ride on alpha (always 1)
        }
        return out
    }

    val IDENTITY4 = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
}
