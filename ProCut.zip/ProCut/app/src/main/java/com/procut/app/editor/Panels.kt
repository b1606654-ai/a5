package com.procut.app.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.procut.app.core.ColorOps
import com.procut.app.ui.GhostButton
import com.procut.app.ui.Muted
import com.procut.app.ui.ProChip
import com.procut.app.ui.ProSlider
import com.procut.app.ui.Red
import com.procut.app.ui.Surface2
import com.procut.app.ui.White
import com.procut.app.ui.pct
import com.procut.app.util.formatTime
import com.procut.app.util.tr
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix

@Composable
fun TrimPanel(s: EditorState, position: () -> Long, onSeekStart: (Long) -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            tr("المدة المحددة: ", "Selected: ") + formatTime(s.trimmedMs()) +
                "   •   ${s.info.width}×${s.info.height}  ${s.info.fps}fps",
            color = White, fontSize = 13.sp
        )
        Text(
            tr("اسحب المقابض الحمراء لقص بداية/نهاية المقطع.", "Drag the red handles to trim the clip."),
            color = Muted, fontSize = 12.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(tr("ابدأ من هنا", "Start here"), Modifier.weight(1f), Icons.Rounded.ContentCut) {
                val p = position().coerceAtMost(s.trimEnd - 500)
                s.trimStart = p.coerceAtLeast(0); onSeekStart(s.trimStart)
            }
            GhostButton(tr("أنهِ هنا", "End here"), Modifier.weight(1f), Icons.Rounded.ContentCut) {
                s.trimEnd = position().coerceAtLeast(s.trimStart + 500).coerceAtMost(s.info.durationMs)
            }
        }
        GhostButton(tr("إعادة ضبط القص", "Reset trim"), Modifier.fillMaxWidth()) {
            s.trimStart = 0; s.trimEnd = s.info.durationMs; onSeekStart(0)
        }
    }
}

@Composable
fun ColorPanel(s: EditorState) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("تحسين تلقائي", "Auto enhance"), color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = s.autoEnhance, onCheckedChange = { s.autoEnhance = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Red, checkedThumbColor = White)
            )
        }
        ProSlider(tr("السطوع", "Brightness"), s.brightness, -1f..1f, pct(s.brightness)) { s.brightness = it }
        ProSlider(tr("التباين", "Contrast"), s.contrast, -1f..1f, pct(s.contrast)) { s.contrast = it }
        ProSlider(tr("التشبّع", "Saturation"), s.saturation, -1f..1f, pct(s.saturation)) { s.saturation = it }
        ProSlider(tr("الدفء", "Warmth"), s.warmth, -1f..1f, pct(s.warmth)) { s.warmth = it }
        GhostButton(tr("إعادة ضبط", "Reset"), Modifier.fillMaxWidth()) {
            s.brightness = 0f; s.contrast = 0f; s.saturation = 0f; s.warmth = 0f; s.autoEnhance = false
        }
    }
}

@Composable
fun FilterPanel(s: EditorState, thumb: ImageBitmap?) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(ColorOps.FILTERS) { f ->
                val sel = s.filterId == f.id
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { s.filterId = f.id }
                ) {
                    Box(
                        Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Surface2)
                            .border(if (sel) 2.dp else 0.dp, if (sel) Red else Color.Transparent, RoundedCornerShape(8.dp))
                    ) {
                        if (thumb != null) {
                            Image(
                                bitmap = thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.size(64.dp),
                                colorFilter = f.matrix?.let { ColorFilter.colorMatrix(ComposeColorMatrix(it)) }
                            )
                        }
                    }
                    Text(tr(f.ar, f.en), color = if (sel) White else Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        if (s.filterId != "none") {
            ProSlider(tr("شدة الفلتر", "Intensity"), s.filterIntensity, 0f..1f, pct(s.filterIntensity)) { s.filterIntensity = it }
        }
    }
}

@Composable
fun TransformPanel(s: EditorState) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(tr("تدوير 90°", "Rotate 90°"), Modifier.weight(1f), Icons.Rounded.RotateRight) {
                s.rotation = (s.rotation + 90) % 360
            }
            GhostButton(tr("قلب أفقي", "Flip"), Modifier.weight(1f), Icons.Rounded.Flip) { s.flipH = !s.flipH }
        }
        Text(tr("اقتصاص بنسبة", "Crop ratio"), color = Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AspectOpt.values().forEach {
                ProChip(if (it == AspectOpt.ORIGINAL) tr("الأصلي", "Original") else it.label, s.aspect == it) { s.aspect = it }
            }
        }
    }
}

@Composable
fun SpeedPanel(s: EditorState) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f).forEach {
                ProChip("${it}x", s.speed == it) { s.speed = it }
            }
        }
        ProSlider(tr("السرعة", "Speed"), s.speed, 0.25f..4f, "%.2fx".format(s.speed)) { s.speed = (it * 20).toInt() / 20f }
    }
}

@Composable
fun AudioPanel(s: EditorState, onPickMusic: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("كتم صوت الفيديو", "Mute original audio"), color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = s.muteOriginal, onCheckedChange = { s.muteOriginal = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Red, checkedThumbColor = White)
            )
        }
        if (!s.muteOriginal) {
            ProSlider(tr("مستوى صوت الفيديو", "Video volume"), s.originalVolume, 0f..2f, pct(s.originalVolume)) { s.originalVolume = it }
        }
        if (s.musicUri == null) {
            GhostButton(tr("إضافة موسيقى", "Add music"), Modifier.fillMaxWidth(), Icons.Rounded.Add) { onPickMusic() }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(Icons.Rounded.MusicNote, null, tint = Red)
                Text(s.musicName, color = White, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                androidx.compose.material3.Icon(
                    Icons.Rounded.Delete, null, tint = Muted,
                    modifier = Modifier.clickable { s.musicUri = null }
                )
            }
            ProSlider(tr("مستوى الموسيقى", "Music volume"), s.musicVolume, 0f..2f, pct(s.musicVolume)) { s.musicVolume = it }
        }
        Text(
            tr("تُقصّ الموسيقى تلقائيًا لتناسب طول الفيديو.", "Music is auto-trimmed to the video length."),
            color = Muted, fontSize = 11.sp
        )
    }
}

@Composable
fun TextPanel(s: EditorState) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = s.text, onValueChange = { s.text = it },
            placeholder = { Text(tr("اكتب نصًا على الفيديو", "Text on video"), color = Muted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions.Default,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, unfocusedBorderColor = Surface2,
                focusedTextColor = White, unfocusedTextColor = White, cursorColor = Red
            )
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(0xFFFFFFFF, 0xFFE50914, 0xFF000000, 0xFFFFD60A).forEach { c ->
                val ci = c.toInt()
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(ci))
                        .border(if (s.textColor == ci) 3.dp else 1.dp, if (s.textColor == ci) Red else Muted, CircleShape)
                        .clickable { s.textColor = ci }
                )
            }
            Spacer(Modifier.weight(1f))
            ProChip(tr("أعلى", "Top"), s.textPos == TextPos.TOP) { s.textPos = TextPos.TOP }
            ProChip(tr("وسط", "Middle"), s.textPos == TextPos.CENTER) { s.textPos = TextPos.CENTER }
            ProChip(tr("أسفل", "Bottom"), s.textPos == TextPos.BOTTOM) { s.textPos = TextPos.BOTTOM }
        }
        ProSlider(tr("الحجم", "Size"), s.textSize, 0.5f..2.5f, "%.1fx".format(s.textSize)) { s.textSize = it }
        Spacer(Modifier.height(4.dp))
    }
}
