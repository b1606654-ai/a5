package com.procut.app.editor

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbMatrix
import com.procut.app.core.ColorOps
import kotlin.math.min
import kotlin.math.roundToInt

enum class AspectOpt(val ratio: Float?, val label: String) {
    ORIGINAL(null, ""), SQUARE(1f, "1:1"), PORTRAIT(9f / 16f, "9:16"),
    LANDSCAPE(16f / 9f, "16:9"), FOUR_FIVE(4f / 5f, "4:5"), CINEMA(21f / 9f, "21:9")
}

enum class TextPos(val y: Float) { TOP(0.8f), CENTER(0f), BOTTOM(-0.8f) }

enum class Quality(val bpp: Float) { LOW(0.06f), MEDIUM(0.10f), HIGH(0.15f), ULTRA(0.22f) }

/** Live-updatable colour matrix used for both preview and export. */
@UnstableApi
class RgbHolder(@Volatile var matrix: FloatArray = ColorOps.IDENTITY4) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = matrix
}

class EditorState(val info: VideoInfo) {
    var trimStart by mutableLongStateOf(0L)
    var trimEnd by mutableLongStateOf(info.durationMs)
    var speed by mutableFloatStateOf(1f)

    var autoEnhance by mutableStateOf(false)
    var brightness by mutableFloatStateOf(0f)
    var contrast by mutableFloatStateOf(0f)
    var saturation by mutableFloatStateOf(0f)
    var warmth by mutableFloatStateOf(0f)
    var filterId by mutableStateOf("none")
    var filterIntensity by mutableFloatStateOf(1f)

    var rotation by mutableIntStateOf(0)       // 0, 90, 180, 270 (clockwise)
    var flipH by mutableStateOf(false)
    var aspect by mutableStateOf(AspectOpt.ORIGINAL)

    var muteOriginal by mutableStateOf(false)
    var originalVolume by mutableFloatStateOf(1f)
    var musicUri by mutableStateOf<Uri?>(null)
    var musicName by mutableStateOf("")
    var musicDurationMs by mutableLongStateOf(0L)
    var musicVolume by mutableFloatStateOf(1f)

    var text by mutableStateOf("")
    var textColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var textPos by mutableStateOf(TextPos.BOTTOM)
    var textSize by mutableFloatStateOf(1f)

    var resolution by mutableIntStateOf(0)     // short side in px, 0 = original
    var fps by mutableIntStateOf(0)            // 0 = original
    var quality by mutableStateOf(Quality.HIGH)

    fun colorMatrix(): FloatArray =
        ColorOps.build(brightness, contrast, saturation, warmth, autoEnhance, filterId, filterIntensity)

    fun trimmedMs(): Long = trimEnd - trimStart
    fun outDurationMs(): Long = (trimmedMs() / speed).toLong()

    /** Final frame size after rotation, crop and resolution choice (even numbers). */
    fun outputSize(): Pair<Int, Int> {
        var w = info.width.toFloat()
        var h = info.height.toFloat()
        if (rotation % 180 != 0) { val t = w; w = h; h = t }
        aspect.ratio?.let { t ->
            val cur = w / h
            if (t > cur) h = w / t else w = h * t
        }
        if (resolution > 0) {
            val k = resolution / min(w, h)
            w *= k; h *= k
        }
        val ew = (w.roundToInt() / 2) * 2
        val eh = (h.roundToInt() / 2) * 2
        return ew.coerceAtLeast(2) to eh.coerceAtLeast(2)
    }

    fun outputFps(): Int = if (fps > 0) min(fps, info.fps) else info.fps

    fun bitrate(): Int {
        val (w, h) = outputSize()
        return (w.toLong() * h * outputFps() * quality.bpp).toLong().coerceIn(1_000_000L, 80_000_000L).toInt()
    }

    fun estimatedBytes(): Long = ((bitrate() + 128_000L) * outDurationMs() / 1000L) / 8L
}
