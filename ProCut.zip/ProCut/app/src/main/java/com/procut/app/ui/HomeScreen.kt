package com.procut.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.procut.app.util.tr

@Composable
fun HomeScreen(onVideo: () -> Unit, onPhoto: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Black).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(Red))
            Text("  ProCut", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(
            tr("استوديو مونتاج احترافي في جيبك", "Pro editing studio in your pocket"),
            color = Muted, fontSize = 14.sp
        )
        Spacer(Modifier.height(8.dp))

        BigCard(
            Icons.Rounded.VideoLibrary,
            tr("مشروع فيديو جديد", "New video project"),
            tr("قص • ألوان • فلاتر • صوت • تصدير بدقة 4K", "Trim • Color • Filters • Audio • up to 4K export"),
            true, onVideo
        )
        BigCard(
            Icons.Rounded.PhotoLibrary,
            tr("تحسين الصور", "Enhance photos"),
            tr("تحسين تلقائي • تقليل الضجيج • حدّة • تكبير ×2", "Auto enhance • Denoise • Sharpen • 2x upscale"),
            false, onPhoto
        )

        Spacer(Modifier.height(8.dp))
        Text(tr("المميزات", "Features"), color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        listOf(
            tr("قص وتقصير المقاطع بمخطط زمني مرئي", "Visual timeline trimming"),
            tr("تحكم بالسطوع والتباين والتشبّع والدفء", "Brightness, contrast, saturation, warmth"),
            tr("12 فلترًا بشدة قابلة للضبط", "12 filters with adjustable intensity"),
            tr("تدوير وقلب واقتصاص (1:1 / 9:16 / 16:9 / 4:5 / 21:9)", "Rotate, flip, crop to any ratio"),
            tr("سرعة من 0.25x إلى 4x", "Speed from 0.25x to 4x"),
            tr("موسيقى خلفية وضبط مستوى الصوت", "Background music & volume mixing"),
            tr("نصوص فوق الفيديو", "Text overlays"),
            tr("تصدير مباشر إلى المعرض بدقة وجودة ومعدل إطارات قابلة للاختيار", "Export to gallery with chosen size, quality & fps")
        ).forEach {
            Row(verticalAlignment = Alignment.Top) {
                Box(Modifier.padding(top = 7.dp).size(6.dp).clip(CircleShape).background(Red))
                Text("  $it", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun BigCard(icon: ImageVector, title: String, sub: String, primary: Boolean, onClick: () -> Unit) {
    val bg = if (primary) Brush.linearGradient(listOf(Red, RedDark)) else Brush.linearGradient(listOf(Surface1, Surface1))
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
            .then(if (primary) Modifier else Modifier.border(1.dp, Surface2, RoundedCornerShape(20.dp)))
            .clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = White, modifier = Modifier.size(40.dp))
        Column(Modifier.padding(start = 16.dp)) {
            Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = if (primary) White.copy(alpha = 0.85f) else Muted, fontSize = 12.sp)
        }
    }
}
