package com.procut.app.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.procut.app.ui.Red
import com.procut.app.ui.White
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val MIN_LEN = 500L

@Composable
fun TrimBar(
    durationMs: Long,
    start: Long,
    end: Long,
    position: () -> Long,
    thumbs: List<ImageBitmap>,
    onStart: (Long) -> Unit,
    onEnd: (Long) -> Unit,
    onSeek: (Long) -> Unit
) {
    // Timeline is always left-to-right, even in Arabic (RTL) layouts.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(60.dp)
                .padding(horizontal = 16.dp)
        ) {
            val density = LocalDensity.current
            val widthPx = with(density) { maxWidth.toPx() }
            val startS by rememberUpdatedState(start)
            val endS by rememberUpdatedState(end)
            val onStartS by rememberUpdatedState(onStart)
            val onEndS by rememberUpdatedState(onEnd)
            val onSeekS by rememberUpdatedState(onSeek)

            fun msToX(ms: Long) = ms.toFloat() / durationMs.coerceAtLeast(1) * widthPx
            fun xToMs(x: Float) = (x / widthPx * durationMs).toLong().coerceIn(0L, durationMs)

            Row(Modifier.fillMaxSize().clip(RoundedCornerShape(6.dp))) {
                thumbs.forEach {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }

            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(durationMs, widthPx) {
                        detectTapGestures { o -> onSeekS(xToMs(o.x).coerceIn(startS, endS)) }
                    }
                    .pointerInput(durationMs, widthPx) {
                        var target = 0 // 0 seek, 1 start, 2 end
                        detectDragGestures(
                            onDragStart = { o ->
                                val sx = msToX(startS)
                                val ex = msToX(endS)
                                val slop = 28.dp.toPx()
                                target = when {
                                    abs(o.x - sx) < slop && abs(o.x - sx) <= abs(o.x - ex) -> 1
                                    abs(o.x - ex) < slop -> 2
                                    else -> 0
                                }
                                if (target == 0) onSeekS(xToMs(o.x).coerceIn(startS, endS))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val ms = xToMs(change.position.x)
                                when (target) {
                                    1 -> onStartS(min(ms, endS - MIN_LEN).coerceAtLeast(0L))
                                    2 -> onEndS(max(ms, startS + MIN_LEN).coerceAtMost(durationMs))
                                    else -> onSeekS(ms.coerceIn(startS, endS))
                                }
                            }
                        )
                    }
            ) {
                val sx = msToX(start)
                val ex = msToX(end)
                val dim = Color.Black.copy(alpha = 0.65f)
                drawRect(dim, Offset(0f, 0f), Size(sx, size.height))
                drawRect(dim, Offset(ex, 0f), Size(size.width - ex, size.height))
                val bw = 3.dp.toPx()
                drawRect(Red, Offset(sx, 0f), Size(ex - sx, bw))
                drawRect(Red, Offset(sx, size.height - bw), Size(ex - sx, bw))
                val hw = 12.dp.toPx()
                val cr = CornerRadius(4.dp.toPx())
                drawRoundRect(Red, Offset(sx, 0f), Size(hw, size.height), cr)
                drawRoundRect(Red, Offset(ex - hw, 0f), Size(hw, size.height), cr)
                drawRect(White, Offset(sx + hw / 2 - 1.dp.toPx(), size.height * 0.3f), Size(2.dp.toPx(), size.height * 0.4f))
                drawRect(White, Offset(ex - hw / 2 - 1.dp.toPx(), size.height * 0.3f), Size(2.dp.toPx(), size.height * 0.4f))
                val px = msToX(position())
                drawRect(White, Offset(px - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
            }
        }
    }
}
