package com.procut.app.ui

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.procut.app.core.ColorOps
import com.procut.app.core.ImageOps
import com.procut.app.core.ImageParams
import com.procut.app.util.Gallery
import com.procut.app.util.stamp
import com.procut.app.util.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix

@Composable
fun ImageScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var params by remember { mutableStateOf(ImageParams()) }
    var tab by remember { mutableIntStateOf(0) }
    var showOriginal by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    BackHandler { onBack() }

    LaunchedEffect(uri) {
        preview = withContext(Dispatchers.Default) { ImageOps.load(ctx, uri, 1280) }
        if (preview == null) Toast.makeText(ctx, tr("تعذّر فتح الصورة", "Could not open image"), Toast.LENGTH_SHORT).show()
    }
    LaunchedEffect(preview, params) {
        val p = preview ?: return@LaunchedEffect
        delay(120)
        busy = true
        result = withContext(Dispatchers.Default) { ImageOps.process(p, params, false) }
        busy = false
    }

    fun save() {
        if (saving) return
        saving = true
        scope.launch {
            val uriOut = withContext(Dispatchers.Default) {
                val full = ImageOps.load(ctx, uri, if (params.upscale) 2000 else 4096) ?: return@withContext null
                val out = ImageOps.process(full, params, true)
                Gallery.saveImage(ctx, out, "ProCut_${stamp()}.jpg")
            }
            saving = false
            Toast.makeText(
                ctx,
                if (uriOut != null) tr("✓ تم الحفظ في المعرض (Pictures/ProCut)", "✓ Saved to gallery (Pictures/ProCut)")
                else tr("فشل الحفظ", "Save failed"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Column(Modifier.fillMaxSize().background(Black).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Close, null, tint = White, modifier = Modifier.clip(CircleShape).clickable { onBack() }.padding(10.dp))
            Text(tr("تحسين الصورة", "Enhance photo"), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f).padding(start = 6.dp))
            PrimaryButton(if (saving) "…" else tr("حفظ", "Save"), icon = Icons.Rounded.Save) { save() }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(8.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onPress = { showOriginal = true; tryAwaitRelease(); showOriginal = false })
                },
            contentAlignment = Alignment.Center
        ) {
            val shown = if (showOriginal) preview else (result ?: preview)
            if (shown != null) {
                Image(shown.asImageBitmap(), null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else CircularProgressIndicator(color = Red)
            if (busy) CircularProgressIndicator(color = Red, strokeWidth = 2.dp, modifier = Modifier.align(Alignment.TopEnd).size(22.dp))
            Text(
                tr("اضغط مطولًا للمقارنة مع الأصل", "Hold to compare with original"),
                color = White.copy(alpha = 0.7f), fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        Column(
            Modifier.fillMaxWidth().height(210.dp).background(Surface1)
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            when (tab) {
                0 -> EnhancePanel(params) { params = it }
                1 -> ColorsPanel(params) { params = it }
                else -> FiltersPanel(params, preview) { params = it }
            }
        }
        Row(Modifier.fillMaxWidth().background(Black), horizontalArrangement = Arrangement.SpaceEvenly) {
            ToolTab(Icons.Rounded.AutoFixHigh, tr("تحسين", "Enhance"), tab == 0) { tab = 0 }
            ToolTab(Icons.Rounded.Tune, tr("ألوان", "Color"), tab == 1) { tab = 1 }
            ToolTab(Icons.Rounded.AutoAwesome, tr("فلاتر", "Filters"), tab == 2) { tab = 2 }
        }
    }
}

@Composable
private fun EnhancePanel(p: ImageParams, set: (ImageParams) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("تحسين تلقائي ذكي", "Smart auto-enhance"), color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = p.auto, onCheckedChange = { set(p.copy(auto = it)) },
                colors = SwitchDefaults.colors(checkedTrackColor = Red, checkedThumbColor = White)
            )
        }
        if (p.auto) ProSlider(tr("قوة التحسين", "Strength"), p.autoStrength, 0f..1f, pct(p.autoStrength)) { set(p.copy(autoStrength = it)) }
        ProSlider(tr("الحدّة", "Sharpness"), p.sharpen, 0f..1f, pct(p.sharpen)) { set(p.copy(sharpen = it)) }
        ProSlider(tr("تقليل الضجيج", "Denoise"), p.denoise, 0f..1f, pct(p.denoise)) { set(p.copy(denoise = it)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("تكبير ×2 عند الحفظ (للصور الصغيرة)", "2x upscale on save (small photos)"), color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = p.upscale, onCheckedChange = { set(p.copy(upscale = it)) },
                colors = SwitchDefaults.colors(checkedTrackColor = Red, checkedThumbColor = White)
            )
        }
    }
}

@Composable
private fun ColorsPanel(p: ImageParams, set: (ImageParams) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        ProSlider(tr("السطوع", "Brightness"), p.brightness, -1f..1f, pct(p.brightness)) { set(p.copy(brightness = it)) }
        ProSlider(tr("التباين", "Contrast"), p.contrast, -1f..1f, pct(p.contrast)) { set(p.copy(contrast = it)) }
        ProSlider(tr("التشبّع", "Saturation"), p.saturation, -1f..1f, pct(p.saturation)) { set(p.copy(saturation = it)) }
        ProSlider(tr("الدفء", "Warmth"), p.warmth, -1f..1f, pct(p.warmth)) { set(p.copy(warmth = it)) }
    }
}

@Composable
private fun FiltersPanel(p: ImageParams, thumb: Bitmap?, set: (ImageParams) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(ColorOps.FILTERS) { f ->
                val sel = p.filterId == f.id
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { set(p.copy(filterId = f.id)) }) {
                    Box(
                        Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)
                            .border(if (sel) 2.dp else 0.dp, if (sel) Red else Color.Transparent, RoundedCornerShape(8.dp))
                    ) {
                        if (thumb != null) Image(
                            thumb.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.size(64.dp),
                            colorFilter = f.matrix?.let { ColorFilter.colorMatrix(ComposeColorMatrix(it)) }
                        )
                    }
                    Text(tr(f.ar, f.en), color = if (sel) White else Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        if (p.filterId != "none") ProSlider(tr("شدة الفلتر", "Intensity"), p.filterIntensity, 0f..1f, pct(p.filterIntensity)) { set(p.copy(filterIntensity = it)) }
    }
}
