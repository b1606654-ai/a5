package com.procut.app.editor

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlin.math.roundToInt

data class VideoInfo(
    val uri: Uri,
    val durationMs: Long,
    val width: Int,      // upright (rotation already applied)
    val height: Int,
    val fps: Int,
    val hasAudio: Boolean
)

fun probeVideo(ctx: Context, uri: Uri): VideoInfo? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        VideoInfo(uri, dur, w, h, probeFps(ctx, uri), hasAudio)
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

private fun probeFps(ctx: Context, uri: Uri): Int {
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, uri, null)
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true &&
                f.containsKey(MediaFormat.KEY_FRAME_RATE)
            ) {
                return try {
                    f.getInteger(MediaFormat.KEY_FRAME_RATE)
                } catch (e: Exception) {
                    try { f.getFloat(MediaFormat.KEY_FRAME_RATE).roundToInt() } catch (e2: Exception) { 30 }
                }
            }
        }
    } catch (e: Exception) {
        // fall through
    } finally {
        ex.release()
    }
    return 30
}

fun probeAudioDuration(ctx: Context, uri: Uri): Long {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } catch (e: Exception) {
        0L
    } finally {
        r.release()
    }
}

fun displayName(ctx: Context, uri: Uri): String {
    return try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "audio"
    } catch (e: Exception) {
        "audio"
    }
}

fun extractThumbs(ctx: Context, info: VideoInfo, count: Int, size: Int): List<Bitmap> {
    val r = MediaMetadataRetriever()
    val out = mutableListOf<Bitmap>()
    try {
        r.setDataSource(ctx, info.uri)
        for (i in 0 until count) {
            val t = (info.durationMs * 1000L * i) / count + 1000L
            val bmp = r.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, size, size)
            if (bmp != null) out += bmp
        }
    } catch (e: Exception) {
        // ignore – timeline just shows fewer frames
    } finally {
        r.release()
    }
    return out
}
