package com.procut.app.editor

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.procut.app.ui.Black
import com.procut.app.ui.GhostButton
import com.procut.app.ui.Muted
import com.procut.app.ui.PrimaryButton
import com.procut.app.ui.ProChip
import com.procut.app.ui.Red
import com.procut.app.ui.Surface1
import com.procut.app.ui.Surface2
import com.procut.app.ui.ToolTab
import com.procut.app.ui.White
import com.procut.app.util.Gallery
import com.procut.app.util.formatTime
import com.procut.app.util.stamp
import com.procut.app.util.tr
import com.procut.app.core.ColorOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

private enum class Tab { TRIM, COLOR, FILTER, TRANSFORM, SPEED, AUDIO, TEXT }

sealed interface ExportUi {
    data object Idle : ExportUi
    data class Running(val progress: Float) : ExportUi
    data class Done(val uri: Uri) : ExportUi
    data class Error(val msg: String) : ExportUi
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(info: VideoInfo, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = remember { EditorState(info) }
    val rgb = remember { RgbHolder() }
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setVideoEffects(listOf(rgb))
            setMediaItem(MediaItem.fromUri(info.uri))
            prepare()
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val pos = remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(Tab.TRIM) }
    var showExport by remember { mutableStateOf(false) }
    var thumbs by remember { mutableStateOf<List<ImageBitmap>>(emptyList()) }
    var export by remember { mutableStateOf<ExportUi>(ExportUi.Idle) }
    var transformer by remember { mutableStateOf<Transformer?>(null) }

    LaunchedEffect(info) {
        thumbs = withContext(Dispatchers.IO) { extractThumbs(ctx, info, 10, 160).map { it.asImageBitmap() } }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // Playback position + keep playback inside the trimmed range.
    LaunchedEffect(player) {
        while (true) {
            val p = player.currentPosition
            pos.longValue = p
            if (player.isPlaying && p >= s.trimEnd) {
                player.pause(); player.seekTo(s.trimStart)
            }
            delay(33)
        }
    }

    // Live colour preview (same matrix as the export).
    val cm by remember { derivedStateOf { s.colorMatrix() } }
    LaunchedEffect(cm) {
        rgb.matrix = ColorOps.toRgb4(cm)
        if (!player.isPlaying) player.seekTo(player.currentPosition)
    }
    LaunchedEffect(s.speed) { player.setPlaybackSpeed(s.speed) }
    LaunchedEffect(s.muteOriginal, s.originalVolume) {
        player.volume = if (s.muteOriginal) 0f else s.originalVolume.coerceAtMost(1f)
    }

    val toggle: () -> Unit = {
        if (player.isPlaying) player.pause() else {
            if (player.currentPosition >= s.trimEnd - 50 || player.currentPosition < s.trimStart) player.seekTo(s.trimStart)
            player.play()
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            s.musicUri = uri
            s.musicName = displayName(ctx, uri)
            s.musicDurationMs = probeAudioDuration(ctx, uri)
        }
    }

    fun startExport() {
        player.pause()
        val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        export = ExportUi.Running(0f)
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                scope.launch {
                    val uri = withContext(Dispatchers.IO) {
                        Gallery.saveVideo(ctx, out, "ProCut_${stamp()}.mp4").also { out.delete() }
                    }
                    export = if (uri != null) ExportUi.Done(uri) else ExportUi.Error(tr("تعذّر الحفظ في المعرض", "Could not save to gallery"))
                }
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                out.delete()
                export = ExportUi.Error(exportException.message ?: "Export failed")
            }
        }
        try {
            val t = Exporter.transformer(ctx, s, listener)
            transformer = t
            t.start(Exporter.composition(s), out.absolutePath)
            scope.launch {
                val h = ProgressHolder()
                while (export is ExportUi.Running) {
                    if (t.getProgress(h) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                        export = ExportUi.Running(h.progress / 100f)
                    }
                    delay(150)
                }
            }
        } catch (e: Exception) {
            export = ExportUi.Error(e.message ?: "Export failed")
        }
    }

    BackHandler {
        if (export is ExportUi.Running) return@BackHandler
        onBack()
    }

    Column(Modifier.fillMaxSize().background(Black).systemBarsPadding()) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Rounded.Close, null, tint = White,
                modifier = Modifier.clip(CircleShape).clickable { onBack() }.padding(10.dp)
            )
            Text("ProCut", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f).padding(start = 6.dp))
            PrimaryButton(tr("تصدير", "Export"), icon = Icons.Rounded.Download) { showExport = true }
        }

        // Preview
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Preview(player, s, toggle, playing)
        }

        // Transport + timeline
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = White,
                modifier = Modifier.size(40.dp).clip(CircleShape).background(Red).clickable { toggle() }.padding(8.dp)
            )
            TimeLabel({ pos.longValue }) { s.info.durationMs }
        }
        TrimBar(
            durationMs = info.durationMs, start = s.trimStart, end = s.trimEnd,
            position = { pos.longValue }, thumbs = thumbs,
            onStart = { s.trimStart = it; player.seekTo(it) },
            onEnd = { s.trimEnd = it; player.seekTo(maxOf(s.trimStart, it - 500)) },
            onSeek = { player.seekTo(it) }
        )

        // Tool panel
        Column(
            Modifier.fillMaxWidth().height(190.dp).background(Surface1)
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            when (tab) {
                Tab.TRIM -> TrimPanel(s, { pos.longValue }) { player.seekTo(it) }
                Tab.COLOR -> ColorPanel(s)
                Tab.FILTER -> FilterPanel(s, thumbs.firstOrNull())
                Tab.TRANSFORM -> TransformPanel(s)
                Tab.SPEED -> SpeedPanel(s)
                Tab.AUDIO -> AudioPanel(s) { musicPicker.launch(arrayOf("audio/*")) }
                Tab.TEXT -> TextPanel(s)
            }
        }

        // Tabs
        Row(Modifier.fillMaxWidth().background(Black).horizontalScroll(rememberScrollState())) {
            ToolTab(Icons.Rounded.ContentCut, tr("قص", "Trim"), tab == Tab.TRIM) { tab = Tab.TRIM }
            ToolTab(Icons.Rounded.Tune, tr("ألوان", "Color"), tab == Tab.COLOR) { tab = Tab.COLOR }
            ToolTab(Icons.Rounded.AutoAwesome, tr("فلاتر", "Filters"), tab == Tab.FILTER) { tab = Tab.FILTER }
            ToolTab(Icons.Rounded.Crop, tr("تحويل", "Transform"), tab == Tab.TRANSFORM) { tab = Tab.TRANSFORM }
            ToolTab(Icons.Rounded.Speed, tr("سرعة", "Speed"), tab == Tab.SPEED) { tab = Tab.SPEED }
            ToolTab(Icons.Rounded.MusicNote, tr("صوت", "Audio"), tab == Tab.AUDIO) { tab = Tab.AUDIO }
            ToolTab(Icons.Rounded.TextFields, tr("نص", "Text"), tab == Tab.TEXT) { tab = Tab.TEXT }
        }
    }

    if (showExport) {
        ModalBottomSheet(
            onDismissRequest = {
                if (export !is ExportUi.Running) { showExport = false; if (export !is ExportUi.Done) export = ExportUi.Idle }
            },
            containerColor = Surface1,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            ExportSheet(
                s = s, export = export,
                onStart = { startExport() },
                onCancel = { transformer?.cancel(); export = ExportUi.Idle },
                onClose = { showExport = false; export = ExportUi.Idle }
            )
        }
    }
}

@Composable
private fun TimeLabel(pos: () -> Long, dur: () -> Long) {
    Text(
        formatTime(pos()) + " / " + formatTime(dur()),
        color = White, fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp)
    )
}

@OptIn(UnstableApi::class)
@Composable
private fun Preview(player: ExoPlayer, s: EditorState, toggle: () -> Unit, playing: Boolean) {
    val src = s.info.width.toFloat() / s.info.height
    val swap = s.rotation % 180 != 0
    val rotAspect = if (swap) 1f / src else src
    Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
        BoxWithConstraints(
            Modifier
                .aspectRatio(rotAspect)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { toggle() }
        ) {
            val w = maxWidth
            val h = maxHeight
            val iw = if (swap) h else w
            val ih = if (swap) w else h
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false
                        this.player = player
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                    }
                },
                modifier = Modifier.requiredSize(iw, ih).graphicsLayer {
                    rotationZ = s.rotation.toFloat()
                    scaleX = if (s.flipH) -1f else 1f
                }
            )
            // Crop guide
            s.aspect.ratio?.let { t ->
                Canvas(Modifier.fillMaxSize()) {
                    val cur = size.width / size.height
                    val rw: Float; val rh: Float
                    if (t > cur) { rw = size.width; rh = rw / t } else { rh = size.height; rw = rh * t }
                    val l = (size.width - rw) / 2; val tp = (size.height - rh) / 2
                    val dim = Color.Black.copy(alpha = 0.6f)
                    drawRect(dim, Offset(0f, 0f), Size(size.width, tp))
                    drawRect(dim, Offset(0f, tp + rh), Size(size.width, size.height - tp - rh))
                    drawRect(dim, Offset(0f, tp), Size(l, rh))
                    drawRect(dim, Offset(l + rw, tp), Size(size.width - l - rw, rh))
                    drawRect(Red, Offset(l, tp), Size(rw, rh), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                }
            }
            // Text preview
            if (s.text.isNotBlank()) {
                val align = when (s.textPos) {
                    TextPos.TOP -> Alignment.TopCenter
                    TextPos.CENTER -> Alignment.Center
                    TextPos.BOTTOM -> Alignment.BottomCenter
                }
                Text(
                    s.text, color = Color(s.textColor), fontWeight = FontWeight.Bold,
                    fontSize = (h.value * 0.07f * s.textSize).sp,
                    modifier = Modifier.align(align).padding(vertical = h * 0.07f, horizontal = 8.dp)
                )
            }
            if (!playing) {
                Icon(
                    Icons.Rounded.PlayArrow, null, tint = White,
                    modifier = Modifier.align(Alignment.Center).size(56.dp).clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.45f)).padding(10.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportSheet(
    s: EditorState,
    export: ExportUi,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(tr("إعدادات التصدير", "Export settings"), color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        when (export) {
            is ExportUi.Running -> {
                Text(tr("جارٍ التصدير… ", "Exporting… ") + "${(export.progress * 100).toInt()}%", color = White)
                LinearProgressIndicator(
                    progress = { export.progress }, color = Red, trackColor = Surface2,
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                )
                GhostButton(tr("إلغاء", "Cancel"), Modifier.fillMaxWidth()) { onCancel() }
            }
            is ExportUi.Done -> {
                Text(tr("✓ تم الحفظ في المعرض (Movies/ProCut)", "✓ Saved to gallery (Movies/ProCut)"), color = White, fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton(tr("فتح", "Open"), Modifier.weight(1f), Icons.Rounded.PlayArrow) {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(export.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                    GhostButton(tr("مشاركة", "Share"), Modifier.weight(1f), Icons.Rounded.Share) {
                        val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, export.uri)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        ctx.startActivity(Intent.createChooser(i, null))
                    }
                }
                PrimaryButton(tr("تم", "Done"), Modifier.fillMaxWidth()) { onClose() }
            }
            else -> {
                if (export is ExportUi.Error) Text(export.msg, color = Red, fontSize = 13.sp)

                Text(tr("الدقة (رفع الجودة)", "Resolution (upscale)"), color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 480, 720, 1080, 1440, 2160).forEach {
                        ProChip(if (it == 0) tr("الأصلي", "Original") else "${it}p", s.resolution == it) { s.resolution = it }
                    }
                }
                Text(tr("معدل الإطارات", "Frame rate"), color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProChip(tr("الأصلي", "Original") + " (${s.info.fps})", s.fps == 0) { s.fps = 0 }
                    listOf(24, 30, 60).filter { it < s.info.fps }.forEach {
                        ProChip("$it fps", s.fps == it) { s.fps = it }
                    }
                }
                Text(tr("الجودة", "Quality"), color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Quality.values().forEach {
                        val label = when (it) {
                            Quality.LOW -> tr("منخفضة", "Low")
                            Quality.MEDIUM -> tr("متوسطة", "Medium")
                            Quality.HIGH -> tr("عالية", "High")
                            Quality.ULTRA -> tr("فائقة", "Ultra")
                        }
                        ProChip(label, s.quality == it) { s.quality = it }
                    }
                }
                val (w, h) = s.outputSize()
                Text(
                    "${w}×${h} • ${s.outputFps()}fps • ~${s.estimatedBytes() / 1_000_000} MB • " + formatTime(s.outDurationMs()),
                    color = White, fontSize = 13.sp
                )
                PrimaryButton(tr("ابدأ التصدير إلى المعرض", "Export to gallery"), Modifier.fillMaxWidth(), Icons.Rounded.Download) { onStart() }
            }
        }
    }
}
