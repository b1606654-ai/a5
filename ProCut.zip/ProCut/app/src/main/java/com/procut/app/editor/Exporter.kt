package com.procut.app.editor

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.procut.app.core.ColorOps
import kotlin.math.min

@UnstableApi
object Exporter {

    private fun volumeProcessor(volume: Float): ChannelMixingAudioProcessor =
        ChannelMixingAudioProcessor().apply {
            for (c in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(c, 2).scaleBy(volume))
        }

    fun composition(s: EditorState): Composition {
        val info = s.info
        val (ow, oh) = s.outputSize()

        val mediaItem = MediaItem.Builder()
            .setUri(info.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(s.trimStart)
                    .setEndPositionMs(s.trimEnd)
                    .build()
            ).build()

        val video = mutableListOf<Effect>()

        // 1) colour (filter + adjustments in one matrix)
        val cm = s.colorMatrix()
        if (!ColorOps.isIdentity(cm)) video += RgbHolder(ColorOps.toRgb4(cm))

        // 2) frame-rate reduction (can only drop frames)
        if (s.fps in 1 until info.fps) video += FrameDropEffect.createDefaultFrameDropEffect(s.fps.toFloat())

        // 3) speed
        if (s.speed != 1f) video += SpeedChangeEffect(s.speed)

        // 4) rotate / flip (Media3 rotates counter-clockwise, UI rotates clockwise)
        if (s.rotation != 0 || s.flipH) {
            video += ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(-s.rotation.toFloat())
                .setScale(if (s.flipH) -1f else 1f, 1f)
                .build()
        }

        // 5) crop to aspect
        s.aspect.ratio?.let { t ->
            var w = info.width.toFloat()
            var h = info.height.toFloat()
            if (s.rotation % 180 != 0) { val x = w; w = h; h = x }
            val cur = w / h
            if (t > cur) {
                val f = cur / t
                video += Crop(-1f, 1f, -f, f)
            } else {
                val f = t / cur
                video += Crop(-f, f, -1f, 1f)
            }
        }

        // 6) output size
        if (s.resolution > 0) video += Presentation.createForWidthAndHeight(ow, oh, Presentation.LAYOUT_SCALE_TO_FIT)

        // 7) text overlay
        if (s.text.isNotBlank()) {
            val px = (oh * 0.07f * s.textSize).toInt().coerceAtLeast(12)
            val span = SpannableString(s.text).apply {
                setSpan(ForegroundColorSpan(s.textColor), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(AbsoluteSizeSpan(px), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(StyleSpan(Typeface.BOLD), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            val settings = OverlaySettings.Builder()
                .setBackgroundFrameAnchor(0f, s.textPos.y)
                .build()
            val overlay = TextOverlay.createStaticTextOverlay(span, settings)
            video += OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))
        }

        val audio = mutableListOf<AudioProcessor>()
        if (s.originalVolume != 1f) audio += volumeProcessor(s.originalVolume)
        if (s.speed != 1f) audio += SonicAudioProcessor().apply { setSpeed(s.speed); setPitch(1f) }

        val main = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(s.muteOriginal || !info.hasAudio)
            .setEffects(Effects(audio, video))
            .build()

        val sequences = mutableListOf(EditedMediaItemSequence(listOf(main)))

        s.musicUri?.let { uri ->
            val clipEnd = min(s.outDurationMs(), s.musicDurationMs.takeIf { it > 0 } ?: s.outDurationMs())
            if (clipEnd > 0) {
                val item = MediaItem.Builder()
                    .setUri(uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(clipEnd)
                            .build()
                    ).build()
                val music = EditedMediaItem.Builder(item)
                    .setRemoveVideo(true)
                    .setEffects(Effects(listOf<AudioProcessor>(volumeProcessor(s.musicVolume)), listOf<Effect>()))
                    .build()
                sequences += EditedMediaItemSequence(listOf(music))
            }
        }
        return Composition.Builder(sequences).build()
    }

    fun transformer(ctx: Context, s: EditorState, listener: Transformer.Listener): Transformer {
        val encoder = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(s.bitrate()).build())
            .setEnableFallback(true)
            .build()
        return Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(listener)
            .build()
    }
}
