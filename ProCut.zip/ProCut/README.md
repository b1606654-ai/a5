# ProCut – Native Android video editor + photo enhancer

Kotlin · Jetpack Compose · Media3 (ExoPlayer + Transformer + Effects). Theme: red / white / black.

## Build
1. Open the `ProCut` folder in **Android Studio (Koala or newer)**, JDK 17.
2. Let Gradle sync (it downloads the dependencies; if Studio asks to create the Gradle wrapper, accept).
3. Run on a device / emulator with Android 10+ (minSdk 29).

> The code was written without access to an Android SDK, so it has NOT been compiled or run yet.
> Expect to fix a few small compile errors on first build (Media3 APIs are marked @UnstableApi).

## Features
Video: visual timeline trim, colour (brightness / contrast / saturation / warmth / auto-enhance),
12 filters with intensity, rotate / flip / crop (1:1, 9:16, 16:9, 4:5, 21:9), speed 0.25x–4x,
background music + volume mixing, text overlay, export size 480p–2160p, fps reduction,
quality presets, saved straight to Movies/ProCut in the gallery, open / share.
Live preview applies the same colour matrix as the export.

Photos: auto-levels + white balance + gamma, edge-preserving denoise, unsharp mask,
colour sliders, filters, 2x upscale (bicubic-style + sharpen), hold-to-compare, saved to Pictures/ProCut.

## Honest limits
- Enhancement is computational (no ML model bundled). For real AI super-resolution / frame
  interpolation add a TFLite model (e.g. Real-ESRGAN, RIFE) and call it from `ImageOps.process`
  or a custom Media3 `GlEffect`.
- Frame rate can only be lowered on export (Media3 drops frames); raising it needs interpolation.
- Music is mixed on export but not previewed live.

## Structure
- `core/ColorOps.kt` – colour matrices, filters
- `core/ImageOps.kt` – photo pipeline
- `editor/` – state, Exporter (Media3 Transformer), TrimBar, panels, EditorScreen
- `ui/` – theme, components, Home, ImageScreen
