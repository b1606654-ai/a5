package com.example.procam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * On-device smart enhance (no network, no model file).
 * level 1 = light, 2 = medium, 3 = strong.
 * Steps: edge-aware denoise -> gentle local contrast -> protected levels/curve -> vibrance.
 */
object Enhancer {
    private const val MAX_EDGE = 3200

    private fun c(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    private fun orientationMatrix(src: ByteArray, fallbackRotation: Int, w: Int, h: Int): Matrix? {
        val exif = try {
            ExifInterface(ByteArrayInputStream(src)).getAttributeInt(ExifInterface.TAG_ORIENTATION, 0)
        } catch (e: Exception) { 0 }
        val m = Matrix()
        when (exif) {
            2 -> m.postScale(-1f, 1f)
            3 -> m.postRotate(180f)
            4 -> m.postScale(1f, -1f)
            5 -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            6 -> m.postRotate(90f)
            7 -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            8 -> m.postRotate(270f)
            1 -> {}
            else -> if (w > h && fallbackRotation % 180 == 90) m.postRotate(fallbackRotation.toFloat())
        }
        return if (m.isIdentity) null else m
    }

    fun enhance(src: ByteArray, fallbackRotation: Int, level: Int): ByteArray? {
        val lv = level.coerceIn(1, 3)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(src, 0, src.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_EDGE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = BitmapFactory.decodeByteArray(src, 0, src.size, opts) ?: return null

        orientationMatrix(src, fallbackRotation, bounds.outWidth, bounds.outHeight)?.let { m ->
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (r !== bmp) bmp.recycle()
            bmp = r
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // mid blur (for denoise) and wide blur (for local contrast)
        val half = Bitmap.createScaledBitmap(bmp, max(1, w / 2), max(1, h / 2), true)
        val midBmp = Bitmap.createScaledBitmap(half, w, h, true)
        val mid = IntArray(w * h)
        midBmp.getPixels(mid, 0, w, 0, 0, w, h)
        val small = Bitmap.createScaledBitmap(bmp, max(1, w / 8), max(1, h / 8), true)
        val wideBmp = Bitmap.createScaledBitmap(small, w, h, true)
        val bl = IntArray(w * h)
        wideBmp.getPixels(bl, 0, w, 0, 0, w, h)
        for (b in listOf(midBmp, wideBmp, half, small)) if (b !== bmp && !b.isRecycled) b.recycle()
        bmp.recycle()

        // strength parameters
        val dn = floatArrayOf(0f, 0.30f, 0.40f, 0.50f)[lv]          // denoise in flat areas
        val clarity = floatArrayOf(0f, 0.10f, 0.18f, 0.28f)[lv]      // local contrast
        val vibrance = floatArrayOf(0f, 0.08f, 0.15f, 0.25f)[lv]     // boosts only dull colours
        val curve = floatArrayOf(0f, 0.08f, 0.14f, 0.20f)[lv]        // S-curve mix
        val strength = lv / 3.0

        // luminance histogram
        val hist = IntArray(256)
        var sum = 0L
        for (p in px) {
            val l = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
            hist[l]++
            sum += l
        }
        val total = px.size
        var acc = 0
        var lo = 0
        for (i in 0..255) { acc += hist[i]; if (acc >= total * 0.001) { lo = i; break } }
        acc = 0
        var hi = 255
        for (i in 255 downTo 0) { acc += hist[i]; if (acc >= total * 0.001) { hi = i; break } }
        lo = min(lo, 12)          // never crush more than the darkest 0.1%
        hi = max(hi, 235)         // never clip highlights harder than that
        if (hi - lo < 40) { lo = 0; hi = 255 }

        val mean = (sum.toDouble() / total / 255.0).coerceIn(0.05, 0.95)
        val target = (ln(0.45) / ln(mean)).coerceIn(0.75, 1.0)       // only brightens dark scenes
        val gamma = 1.0 - (1.0 - target) * strength

        val lut = IntArray(256)
        for (v in 0..255) {
            var x = ((v - lo).toDouble() / (hi - lo)).coerceIn(0.0, 1.0)
            x = x.pow(gamma)
            val s = x * x * (3 - 2 * x)
            x = x * (1 - curve) + s * curve
            lut[v] = (x * 255.0 + 0.5).toInt().coerceIn(0, 255)
        }

        for (i in px.indices) {
            val p = px[i]
            val m = mid[i]
            val q = bl[i]
            var r = (p shr 16) and 255
            var g = (p shr 8) and 255
            var b = p and 255
            val mr = (m shr 16) and 255
            val mg = (m shr 8) and 255
            val mb = m and 255

            // edge-aware denoise: blend toward the soft copy only where the area is flat
            val d = abs(((r - mr) * 77 + (g - mg) * 150 + (b - mb) * 29) shr 8)
            val wgt = dn * max(0f, 1f - d / 24f)
            r += ((mr - r) * wgt).toInt()
            g += ((mg - g) * wgt).toInt()
            b += ((mb - b) * wgt).toInt()

            // gentle local contrast
            r = c(r + ((r - ((q shr 16) and 255)) * clarity).toInt())
            g = c(g + ((g - ((q shr 8) and 255)) * clarity).toInt())
            b = c(b + ((b - (q and 255)) * clarity).toInt())

            r = lut[r]; g = lut[g]; b = lut[b]

            // vibrance: lift dull colours, leave saturated ones alone
            val l = (r * 77 + g * 150 + b * 29) shr 8
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
            val k = 1f + vibrance * (1f - sat)
            r = c(l + ((r - l) * k).toInt())
            g = c(l + ((g - l) * k).toInt())
            b = c(l + ((b - l) * k).toInt())

            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 95, bos)
        out.recycle()
        return bos.toByteArray()
    }
}
