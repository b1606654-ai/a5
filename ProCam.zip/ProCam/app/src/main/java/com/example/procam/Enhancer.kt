package com.example.procam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import java.io.ByteArrayOutputStream
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

/**
 * On-device smart enhance (no network, no model file):
 * auto-levels, adaptive brightening of dark scenes, gentle S-curve,
 * local contrast ("clarity") and a light saturation boost.
 */
object Enhancer {
    private const val MAX_EDGE = 3200

    private fun c(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    fun enhance(src: ByteArray, rotation: Int): ByteArray? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(src, 0, src.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_EDGE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = BitmapFactory.decodeByteArray(src, 0, src.size, opts) ?: return null
        if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (r !== bmp) bmp.recycle()
            bmp = r
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // blurred copy used for local contrast
        val small = Bitmap.createScaledBitmap(bmp, max(1, w / 8), max(1, h / 8), true)
        val blurBmp = Bitmap.createScaledBitmap(small, w, h, true)
        val bl = IntArray(w * h)
        blurBmp.getPixels(bl, 0, w, 0, 0, w, h)
        if (blurBmp !== small && blurBmp !== bmp) blurBmp.recycle()
        if (small !== bmp) small.recycle()
        bmp.recycle()

        // luminance histogram
        val hist = IntArray(256)
        var sum = 0L
        for (p in px) {
            val l = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
            hist[l]++
            sum += l
        }
        val total = px.size
        var acc = 0
        var lo = 0
        for (i in 0..255) { acc += hist[i]; if (acc >= total * 0.004) { lo = i; break } }
        acc = 0
        var hi = 255
        for (i in 255 downTo 0) { acc += hist[i]; if (acc >= total * 0.004) { hi = i; break } }
        if (hi - lo < 40) { lo = 0; hi = 255 }

        val mean = (sum.toDouble() / total / 255.0).coerceIn(0.05, 0.95)
        val gamma = (ln(0.45) / ln(mean)).coerceIn(0.65, 1.0) // <1 brightens dark scenes

        val lut = IntArray(256)
        for (v in 0..255) {
            var x = ((v - lo).toDouble() / (hi - lo)).coerceIn(0.0, 1.0)
            x = x.pow(gamma)
            val s = x * x * (3 - 2 * x)
            x = x * 0.8 + s * 0.2
            lut[v] = (x * 255.0 + 0.5).toInt().coerceIn(0, 255)
        }

        for (i in px.indices) {
            val p = px[i]
            val q = bl[i]
            var r = (p shr 16) and 255
            var g = (p shr 8) and 255
            var b = p and 255
            r = c(r + ((r - ((q shr 16) and 255)) * 0.55f).toInt())
            g = c(g + ((g - ((q shr 8) and 255)) * 0.55f).toInt())
            b = c(b + ((b - (q and 255)) * 0.55f).toInt())
            r = lut[r]; g = lut[g]; b = lut[b]
            val l = (r * 77 + g * 150 + b * 29) shr 8
            r = c(l + ((r - l) * 1.12f).toInt())
            g = c(l + ((g - l) * 1.12f).toInt())
            b = c(l + ((b - l) * 1.12f).toInt())
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 95, bos)
        out.recycle()
        return bos.toByteArray()
    }
}
