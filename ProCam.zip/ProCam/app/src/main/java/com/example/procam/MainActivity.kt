package com.example.procam

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.widget.*
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.pow

class MainActivity : Activity(), SensorEventListener {
    private lateinit var tv: TextureView
    private lateinit var cam: CameraController
    private lateinit var info: TextView
    private lateinit var btnShutter: View
    private lateinit var btnLimit: TextView
    private lateinit var btnEnhance: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnGrid: TextView
    private lateinit var btnWb: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvZoom: TextView
    private lateinit var proPanel: View
    private lateinit var overlay: OverlayView
    private lateinit var focusRing: View
    private lateinit var sm: SensorManager
    private var ids = listOf<String>()
    private var idx = 0
    private val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    private val ui = Handler(Looper.getMainLooper())
    private val limits = intArrayOf(0, 15, 30, 60, 300)
    private val limitLabels = arrayOf("∞", "15ث", "30ث", "60ث", "5د")
    private var limitIdx = 0
    private var recStart = 0L
    private val wbNames = arrayOf("تلقائي", "متوهج", "فلورسنت", "نهار", "غائم")

    private val tick = object : Runnable {
        override fun run() {
            if (!cam.recording) return
            val sec = ((SystemClock.elapsedRealtime() - recStart) / 1000).toInt()
            tvTimer.text = "● %02d:%02d".format(sec / 60, sec % 60)
            val lim = limits[limitIdx]
            if (lim > 0 && sec >= lim) { cam.toggleRecord(); return }
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.texture)
        info = findViewById(R.id.info)
        btnShutter = findViewById(R.id.btnShutter)
        btnLimit = findViewById(R.id.btnLimit)
        btnEnhance = findViewById(R.id.btnEnhance)
        btnFlash = findViewById(R.id.btnFlash)
        btnGrid = findViewById(R.id.btnGrid)
        btnWb = findViewById(R.id.btnWb)
        tvTimer = findViewById(R.id.tvTimer)
        tvZoom = findViewById(R.id.tvZoom)
        proPanel = findViewById(R.id.proPanel)
        overlay = findViewById(R.id.overlay)
        focusRing = findViewById(R.id.focusRing)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        cam = CameraController(this, tv) { m -> runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } }
        cam.onReady = {
            fitPreview(); setupControls()
            btnFlash.visibility = if (cam.hasFlash) View.VISIBLE else View.GONE
            styleFlash(); cam.start(); showZoom()
        }
        cam.onRecState = { rec ->
            runOnUiThread {
                if (rec) {
                    recStart = SystemClock.elapsedRealtime()
                    tvTimer.text = "● 00:00"
                    tvTimer.visibility = View.VISIBLE
                    btnShutter.setBackgroundResource(R.drawable.shutter_rec)
                    ui.post(tick)
                } else {
                    tvTimer.visibility = View.GONE
                    btnShutter.setBackgroundResource(
                        if (cam.mode == Mode.VIDEO) R.drawable.shutter_video else R.drawable.shutter)
                }
            }
        }
        ids = cam.cameraIds()

        // Pinch = zoom, tap = focus + meter at that point
        val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                cam.zoomTo(cam.zoom * d.scaleFactor); showZoom(); return true
            }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (!sgd.isInProgress && tv.width > 0 && tv.height > 0) {
                    cam.focusAt(e.x / tv.width, e.y / tv.height)
                    showRing(e.x, e.y)
                }
                return true
            }
        })
        tv.setOnTouchListener { _, e -> sgd.onTouchEvent(e); gd.onTouchEvent(e); true }
        tvZoom.setOnClickListener { cam.zoomTo(1f); showZoom() }

        findViewById<RadioGroup>(R.id.modes).setOnCheckedChangeListener { _, id ->
            val m = when (id) {
                R.id.rbVideo -> Mode.VIDEO; R.id.rbNight -> Mode.NIGHT
                R.id.rbHdr -> Mode.HDR; else -> Mode.PHOTO
            }
            btnLimit.visibility = if (m == Mode.VIDEO) View.VISIBLE else View.INVISIBLE
            btnShutter.setBackgroundResource(if (m == Mode.VIDEO) R.drawable.shutter_video else R.drawable.shutter)
            cam.changeMode(m)
        }

        btnShutter.setOnClickListener {
            if (cam.mode == Mode.VIDEO) cam.toggleRecord() else cam.capture()
        }
        btnLimit.setOnClickListener {
            if (!cam.recording) {
                limitIdx = (limitIdx + 1) % limits.size
                btnLimit.text = "⏱ " + limitLabels[limitIdx]
            }
        }
        findViewById<View>(R.id.btnSwitch).setOnClickListener {
            if (ids.size > 1 && !cam.recording) {
                idx = (idx + 1) % ids.size
                Toast.makeText(this, cam.label(ids[idx]), Toast.LENGTH_SHORT).show()
                cam.open(ids[idx])
            }
        }
        findViewById<View>(R.id.btnPro).setOnClickListener {
            proPanel.visibility = if (proPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnFlash.setOnClickListener {
            cam.flashMode = (cam.flashMode + 1) % 3
            styleFlash(); cam.refresh()
            Toast.makeText(this,
                when (cam.flashMode) {
                    0 -> "الفلاش تلقائي"
                    1 -> if (cam.mode == Mode.VIDEO) "ضوء الفيديو مفعّل" else "الفلاش دائماً"
                    else -> "الفلاش متوقف"
                }, Toast.LENGTH_SHORT).show()
        }
        btnGrid.setOnClickListener {
            overlay.showGrid = !overlay.showGrid
            btnGrid.setBackgroundResource(if (overlay.showGrid) R.drawable.bg_chip_on else R.drawable.bg_pill)
            btnGrid.setTextColor(if (overlay.showGrid) Color.BLACK else Color.WHITE)
            overlay.invalidate()
        }
        btnEnhance.setOnClickListener {
            cam.aiLevel = (cam.aiLevel + 1) % 4
            styleEnhance()
            Toast.makeText(this,
                when (cam.aiLevel) {
                    1 -> "تحسين ذكي: خفيف (نسخة إضافية _AI)"
                    2 -> "تحسين ذكي: متوسط (نسخة إضافية _AI)"
                    3 -> "تحسين ذكي: قوي (نسخة إضافية _AI)"
                    else -> "التحسين الذكي متوقف"
                }, Toast.LENGTH_SHORT).show()
        }
        btnWb.setOnClickListener {
            cam.awbIdx = (cam.awbIdx + 1) % wbNames.size
            btnWb.text = "WB: " + wbNames[cam.awbIdx]
            cam.refresh()
        }
        findViewById<Switch>(R.id.swManual).setOnCheckedChangeListener { _, on -> cam.manual = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swFocus).setOnCheckedChangeListener { _, on -> cam.manualFocus = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swRaw).setOnCheckedChangeListener { _, on ->
            cam.rawEnabled = on && cam.hasRaw
            if (on && !cam.hasRaw) Toast.makeText(this, "RAW غير مدعوم في هذه العدسة", Toast.LENGTH_SHORT).show()
            cam.start()
        }
    }

    private fun showRing(x: Float, y: Float) {
        val half = 36 * resources.displayMetrics.density
        focusRing.animate().cancel()
        focusRing.translationX = x - half
        focusRing.translationY = y - half
        focusRing.alpha = 1f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).start()
    }

    private fun styleFlash() {
        btnFlash.text = when (cam.flashMode) { 0 -> "⚡A"; 1 -> "⚡"; else -> "⚡✕" }
        val on = cam.flashMode == 1
        btnFlash.setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_pill)
        btnFlash.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun styleEnhance() {
        val on = cam.aiLevel > 0
        btnEnhance.setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_pill)
        btnEnhance.setTextColor(if (on) Color.BLACK else Color.WHITE)
        btnEnhance.text = if (on) "✨${cam.aiLevel}" else "✨"
    }

    private fun showZoom() { tvZoom.text = "%.1f×".format(cam.zoom) }

    private fun setupControls() {
        val isoR = cam.isoRange; val expR = cam.expRange
        val sIso = findViewById<SeekBar>(R.id.seekIso)
        val sExp = findViewById<SeekBar>(R.id.seekShutter)
        val sFoc = findViewById<SeekBar>(R.id.seekFocus)
        val sEv = findViewById<SeekBar>(R.id.seekEv)
        if (isoR != null) {
            cam.iso = isoR.lower
            sIso.onChange { cam.iso = isoR.lower + (it * (isoR.upper - isoR.lower) / 1000); cam.refresh(); updateInfo() }
        }
        if (expR != null) {
            val hi = minOf(expR.upper, 1_000_000_000L).toDouble()
            val lo = expR.lower.toDouble()
            cam.exposureNs = lo.toLong()
            sExp.onChange { cam.exposureNs = (lo * (hi / lo).pow(it / 1000.0)).toLong(); cam.refresh(); updateInfo() }
        }
        sFoc.onChange { cam.focus = it / 1000f * cam.minFocus; cam.refresh(); updateInfo() }
        val er = cam.evRange
        cam.ev = 0
        if (er != null && er.upper > er.lower) {
            sEv.max = er.upper - er.lower
            sEv.progress = -er.lower
            sEv.isEnabled = true
            sEv.onChange { cam.ev = er.lower + it; cam.refresh(); updateInfo() }
        } else sEv.isEnabled = false
        findViewById<Switch>(R.id.swRaw).isEnabled = cam.hasRaw
        findViewById<Switch>(R.id.swManual).isEnabled = cam.hasManual
        sIso.isEnabled = cam.hasManual; sExp.isEnabled = cam.hasManual; sFoc.isEnabled = cam.minFocus > 0f
        updateInfo()
    }

    private fun updateInfo() {
        val shutter = if (cam.exposureNs >= 500_000_000L) "%.1fs".format(cam.exposureNs / 1e9)
        else "1/${(1e9 / cam.exposureNs).toInt()}"
        info.text = buildString {
            append(if (cam.manual) "ISO ${cam.iso} • $shutter" else "تعريض تلقائي")
            if (!cam.manual && cam.ev != 0) append(" (EV %+.1f)".format(cam.ev * cam.evStep))
            append(" • ")
            append(if (cam.manualFocus) "تركيز %.1f د".format(cam.focus) else "AF")
            append(if (cam.hasRaw) " • RAW✔" else "")
        }
    }

    private fun fitPreview() {
        val w = resources.displayMetrics.widthPixels
        val h = w * cam.previewSize.width / cam.previewSize.height
        tv.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.TOP)
        overlay.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.TOP)
    }

    private fun SeekBar.onChange(f: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) f(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun openCamera() { if (ids.isNotEmpty()) cam.open(ids[idx]) }

    // ---- level (horizon) sensor ----
    override fun onSensorChanged(e: SensorEvent) {
        if (!overlay.showGrid) return
        val ax = e.values[0]
        val ay = e.values[1]
        overlay.roll = Math.toDegrees(atan2(ax.toDouble(), ay.toDouble())).toFloat()
        overlay.upright = abs(ay) > 4f
        overlay.invalidate()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(perms, 1); return
        }
        if (tv.isAvailable) openCamera()
        else tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.all { it == PackageManager.PERMISSION_GRANTED }) onResume()
        else Toast.makeText(this, "الأذونات مطلوبة", Toast.LENGTH_LONG).show()
    }

    override fun onPause() { sm.unregisterListener(this); cam.close(); super.onPause() }
    override fun onDestroy() { cam.release(); super.onDestroy() }
}
