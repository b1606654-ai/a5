package com.example.procam

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.widget.*
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var tv: TextureView
    private lateinit var cam: CameraController
    private lateinit var info: TextView
    private lateinit var btnShutter: View
    private lateinit var btnLimit: TextView
    private lateinit var btnEnhance: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvZoom: TextView
    private lateinit var proPanel: View
    private var ids = listOf<String>()
    private var idx = 0
    private val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    private val ui = Handler(Looper.getMainLooper())
    private val limits = intArrayOf(0, 15, 30, 60, 300)
    private val limitLabels = arrayOf("∞", "15ث", "30ث", "60ث", "5د")
    private var limitIdx = 0
    private var recStart = 0L

    private val tick = object : Runnable {
        override fun run() {
            if (!cam.recording) return
            val sec = ((SystemClock.elapsedRealtime() - recStart) / 1000).toInt()
            tvTimer.text = "● %02d:%02d".format(sec / 60, sec % 60)
            val lim = limits[limitIdx]
            if (lim > 0 && sec >= lim) { cam.toggleRecord(); return }
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.texture)
        info = findViewById(R.id.info)
        btnShutter = findViewById(R.id.btnShutter)
        btnLimit = findViewById(R.id.btnLimit)
        btnEnhance = findViewById(R.id.btnEnhance)
        tvTimer = findViewById(R.id.tvTimer)
        tvZoom = findViewById(R.id.tvZoom)
        proPanel = findViewById(R.id.proPanel)

        cam = CameraController(this, tv) { m -> runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } }
        cam.onReady = { fitPreview(); setupControls(); cam.start(); showZoom() }
        cam.onRecState = { rec ->
            runOnUiThread {
                if (rec) {
                    recStart = SystemClock.elapsedRealtime()
                    tvTimer.text = "● 00:00"
                    tvTimer.visibility = View.VISIBLE
                    btnShutter.setBackgroundResource(R.drawable.shutter_rec)
                    ui.post(tick)
                } else {
                    tvTimer.visibility = View.GONE
                    btnShutter.setBackgroundResource(
                        if (cam.mode == Mode.VIDEO) R.drawable.shutter_video else R.drawable.shutter)
                }
            }
        }
        ids = cam.cameraIds()

        // Pinch to zoom + tap the zoom pill to reset
        val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                cam.zoomTo(cam.zoom * d.scaleFactor); showZoom(); return true
            }
        })
        tv.setOnTouchListener { _, e -> sgd.onTouchEvent(e); true }
        tvZoom.setOnClickListener { cam.zoomTo(1f); showZoom() }

        findViewById<RadioGroup>(R.id.modes).setOnCheckedChangeListener { _, id ->
            val m = when (id) {
                R.id.rbVideo -> Mode.VIDEO; R.id.rbNight -> Mode.NIGHT
                R.id.rbHdr -> Mode.HDR; else -> Mode.PHOTO
            }
            btnLimit.visibility = if (m == Mode.VIDEO) View.VISIBLE else View.INVISIBLE
            btnShutter.setBackgroundResource(if (m == Mode.VIDEO) R.drawable.shutter_video else R.drawable.shutter)
            cam.changeMode(m)
        }

        btnShutter.setOnClickListener {
            if (cam.mode == Mode.VIDEO) cam.toggleRecord() else cam.capture()
        }
        btnLimit.setOnClickListener {
            if (!cam.recording) {
                limitIdx = (limitIdx + 1) % limits.size
                btnLimit.text = "⏱ " + limitLabels[limitIdx]
            }
        }
        findViewById<View>(R.id.btnSwitch).setOnClickListener {
            if (ids.size > 1 && !cam.recording) {
                idx = (idx + 1) % ids.size
                Toast.makeText(this, cam.label(ids[idx]), Toast.LENGTH_SHORT).show()
                cam.open(ids[idx])
            }
        }
        findViewById<View>(R.id.btnPro).setOnClickListener {
            proPanel.visibility = if (proPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnEnhance.setOnClickListener {
            cam.aiLevel = (cam.aiLevel + 1) % 4
            styleEnhance()
            Toast.makeText(this,
                if (cam.aiLevel > 0) "التحسين الذكي: تُحفظ نسخة محسّنة بجانب الأصلية" else "التحسين الذكي متوقف",
                Toast.LENGTH_SHORT).show()
        }
        findViewById<Switch>(R.id.swManual).setOnCheckedChangeListener { _, on -> cam.manual = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swFocus).setOnCheckedChangeListener { _, on -> cam.manualFocus = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swRaw).setOnCheckedChangeListener { _, on ->
            cam.rawEnabled = on && cam.hasRaw
            if (on && !cam.hasRaw) Toast.makeText(this, "RAW غير مدعوم في هذه العدسة", Toast.LENGTH_SHORT).show()
            cam.start()
        }
    }

    private fun styleEnhance() {
        val on = cam.aiLevel > 0
        btnEnhance.setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_pill)
        btnEnhance.setTextColor(if (on) Color.BLACK else Color.WHITE)
        btnEnhance.text = when (cam.aiLevel) {
            1 -> "✨ خفيف"; 2 -> "✨ متوسط"; 3 -> "✨ قوي"; else -> "✨ ذكي"
        }
    }

    private fun showZoom() { tvZoom.text = "%.1f×".format(cam.zoom) }

    private fun setupControls() {
        val isoR = cam.isoRange; val expR = cam.expRange
        val sIso = findViewById<SeekBar>(R.id.seekIso)
        val sExp = findViewById<SeekBar>(R.id.seekShutter)
        val sFoc = findViewById<SeekBar>(R.id.seekFocus)
        if (isoR != null) {
            cam.iso = isoR.lower
            sIso.onChange { cam.iso = isoR.lower + (it * (isoR.upper - isoR.lower) / 1000); cam.refresh(); updateInfo() }
        }
        if (expR != null) {
            val hi = minOf(expR.upper, 1_000_000_000L).toDouble()
            val lo = expR.lower.toDouble()
            cam.exposureNs = lo.toLong()
            sExp.onChange { cam.exposureNs = (lo * (hi / lo).pow(it / 1000.0)).toLong(); cam.refresh(); updateInfo() }
        }
        sFoc.onChange { cam.focus = it / 1000f * cam.minFocus; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swRaw).isEnabled = cam.hasRaw
        findViewById<Switch>(R.id.swManual).isEnabled = cam.hasManual
        sIso.isEnabled = cam.hasManual; sExp.isEnabled = cam.hasManual; sFoc.isEnabled = cam.minFocus > 0f
        updateInfo()
    }

    private fun updateInfo() {
        val shutter = if (cam.exposureNs >= 500_000_000L) "%.1fs".format(cam.exposureNs / 1e9)
        else "1/${(1e9 / cam.exposureNs).toInt()}"
        info.text = buildString {
            append(if (cam.manual) "ISO ${cam.iso} • $shutter" else "تعريض تلقائي")
            append(" • ")
            append(if (cam.manualFocus) "تركيز %.1f د".format(cam.focus) else "AF")
            append(if (cam.hasRaw) " • RAW✔" else "")
        }
    }

    private fun fitPreview() {
        val w = resources.displayMetrics.widthPixels
        val h = w * cam.previewSize.width / cam.previewSize.height
        tv.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.TOP)
    }

    private fun SeekBar.onChange(f: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) f(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun openCamera() { if (ids.isNotEmpty()) cam.open(ids[idx]) }

    override fun onResume() {
        super.onResume()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(perms, 1); return
        }
        if (tv.isAvailable) openCamera()
        else tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.all { it == PackageManager.PERMISSION_GRANTED }) onResume()
        else Toast.makeText(this, "الأذونات مطلوبة", Toast.LENGTH_LONG).show()
    }

    override fun onPause() { cam.close(); super.onPause() }
    override fun onDestroy() { cam.release(); super.onDestroy() }
}
