package com.example.procam

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.*
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

enum class Mode { PHOTO, VIDEO, NIGHT, HDR }

/** Camera2 controller: manual sensor controls, RAW/DNG, 4K60 video, HDR & night. */
class CameraController(
    private val ctx: Context,
    private val tv: TextureView,
    private val onMsg: (String) -> Unit
) {
    private val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("cam").apply { start() }
    private val handler = Handler(thread.looper)
    private val ui = Handler(Looper.getMainLooper())

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var forceHd = false
    private var prevSurf: Surface? = null

    /** One Surface reused for every session (creating several from one texture crashes). */
    private fun surfaceFor(st: SurfaceTexture): Surface =
        prevSurf?.takeIf { it.isValid } ?: Surface(st).also { prevSurf = it }

    private fun abortRecorder() {
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        markRecording(false)
    }
    private var targets: List<Surface> = emptyList()
    private var template = CameraDevice.TEMPLATE_PREVIEW
    private var videoSize = Size(1920, 1080)
    private var videoFps = 30
    private var videoRange: Range<Int>? = null
    private val rawImages = HashMap<Long, Image>()
    private val results = HashMap<Long, TotalCaptureResult>()

    lateinit var chars: CameraCharacteristics
        private set
    var previewSize = Size(1920, 1080)
        private set
    var recording = false
        private set
    var mode = Mode.PHOTO
    var manual = false
    var manualFocus = false
    var rawEnabled = false
    var iso = 100
    var exposureNs = 10_000_000L
    var focus = 0f
    var onReady: (() -> Unit)? = null
    var onRecState: ((Boolean) -> Unit)? = null
    var aiLevel = 0 // 0 = off, 1..3 = light/medium/strong
    var zoom = 1f
    var flashMode = 0 // 0 = auto, 1 = on, 2 = off
    var ev = 0        // exposure compensation (in EV steps)
    var awbIdx = 0    // 0 = auto, then presets
    @Volatile private var torchOn = false
    @Volatile private var aeState = -1
    private var meter: MeteringRectangle? = null
    private val awbValues = intArrayOf(
        CameraMetadata.CONTROL_AWB_MODE_AUTO, CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
        CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT, CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
        CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT)
    val hasFlash: Boolean get() = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    val evRange: Range<Int>? get() = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
    val evStep: Float get() = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f

    val minZoom: Float
        get() = if (Build.VERSION.SDK_INT >= 30) chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f else 1f
    val maxZoom: Float
        get() = minOf(
            if (Build.VERSION.SDK_INT >= 30) chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.upper ?: 1f
            else chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f, 20f)

    fun zoomTo(z: Float) {
        if (device == null) return
        zoom = z.coerceIn(minZoom, maxZoom)
        refresh()
    }

    /** Tap-to-focus / meter: nx, ny are 0..1 positions inside the preview view. */
    fun focusAt(nx: Float, ny: Float) {
        if (device == null || manualFocus) return
        if ((chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) <= 0) return
        val a = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val cw = (a.width() / zoom).toInt()
        val ch = (a.height() / zoom).toInt()
        val left = a.centerX() - cw / 2
        val top = a.centerY() - ch / 2
        val uv = when (chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90) {
            90 -> Pair(ny, 1f - nx)
            270 -> Pair(1f - ny, nx)
            180 -> Pair(1f - nx, 1f - ny)
            else -> Pair(nx, ny)
        }
        val half = minOf(cw, ch) / 10
        val x = (left + (uv.first * cw).toInt() - half).coerceIn(a.left, a.right - 2 * half)
        val y = (top + (uv.second * ch).toInt() - half).coerceIn(a.top, a.bottom - 2 * half)
        meter = MeteringRectangle(x, y, 2 * half, 2 * half, MeteringRectangle.METERING_WEIGHT_MAX)
        refresh()
    }

    private fun markRecording(v: Boolean) { recording = v; ui.post { onRecState?.invoke(v) } }

    // ---------- capabilities ----------
    private fun caps() = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
    val hasRaw get() = caps().contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW)
    val hasManual get() = caps().contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
    val isoRange: Range<Int>? get() = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val expRange: Range<Long>? get() = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val minFocus: Float get() = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    private fun has(a: IntArray?, v: Int) = a?.contains(v) == true

    fun cameraIds(): List<String> = mgr.cameraIdList.filter {
        has(mgr.getCameraCharacteristics(it).get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES),
            CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)
    }

    fun label(id: String): String {
        val c = mgr.getCameraCharacteristics(id)
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
        val front = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        return (if (front) "أمامية" else "خلفية") + " #$id ${f}mm"
    }

    // ---------- open / close ----------
    @SuppressLint("MissingPermission")
    fun open(id: String) {
        close()
        forceHd = false
        chars = mgr.getCameraCharacteristics(id)
        zoom = 1f.coerceIn(minZoom, maxZoom)
        meter = null
        torchOn = false
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java)
        previewSize = sizes.filter { it.width * 9 == it.height * 16 && it.width <= 1920 }
            .maxByOrNull { it.width * it.height } ?: sizes.first()
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { device = d; ui.post { onReady?.invoke() } }
            override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
            override fun onError(d: CameraDevice, e: Int) { d.close(); device = null; onMsg("خطأ في الكاميرا: $e") }
        }, handler)
    }

    fun close() {
        if (recording) stopRecording(restart = false)
        closeSession()
        device?.close(); device = null
    }

    fun release() { close(); try { prevSurf?.release() } catch (e: Exception) {}; prevSurf = null; thread.quitSafely() }

    private fun closeSession() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        jpegReader?.close(); jpegReader = null
        rawReader?.close(); rawReader = null
    }

    // ---------- preview session ----------
    fun changeMode(m: Mode) { if (recording) return; mode = m; start() }

    fun start() {
        try { startInternal() } catch (e: Exception) { onMsg("خطأ: ${e.message}") }
    }

    private fun startInternal() {
        torchOn = false
        val d = device ?: return
        val st = tv.surfaceTexture ?: return
        closeSession()
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val ps = surfaceFor(st)
        val surfaces = mutableListOf(ps)
        if (mode != Mode.VIDEO) {
            setupReaders()
            surfaces += jpegReader!!.surface
            if (rawEnabled) rawReader?.let { surfaces += it.surface }
        }
        targets = listOf(ps)
        template = CameraDevice.TEMPLATE_PREVIEW
        openSession(d, surfaces) {}
    }

    private fun openSession(d: CameraDevice, surfaces: List<Surface>, after: () -> Unit) {
        @Suppress("DEPRECATION")
        d.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                refresh()
                try { after() } catch (e: Exception) {
                    onMsg("فشل بدء التسجيل: ${e.message}")
                    abortRecorder()
                    ui.post { start() }
                }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) {
                if (template == CameraDevice.TEMPLATE_RECORD) {
                    abortRecorder()
                    if (!forceHd) { forceHd = true; onMsg("4K غير مدعوم، تجربة 1080p"); ui.post { toggleRecord() } }
                    else { onMsg("الجهاز لا يدعم التسجيل بهذا الإعداد"); ui.post { start() } }
                } else onMsg("الجهاز لا يدعم هذا الإعداد")
            }
        }, handler)
    }

    /** Re-send the repeating request after any parameter change. */
    fun refresh() {
        val s = session ?: return
        val d = device ?: return
        try {
            val b = d.createCaptureRequest(template)
            targets.forEach { b.addTarget(it) }
            applyParams(b, template)
            s.setRepeatingRequest(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(ss: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                    aeState = res.get(CaptureResult.CONTROL_AE_STATE) ?: -1
                }
            }, handler)
        } catch (e: Exception) { onMsg(e.message ?: "خطأ") }
    }

    private fun applyParams(b: CaptureRequest.Builder, tpl: Int) {
        val c = chars
        val video = tpl == CameraDevice.TEMPLATE_RECORD
        val still = tpl == CameraDevice.TEMPLATE_STILL_CAPTURE
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)

        // Zoom
        if (Build.VERSION.SDK_INT >= 30) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        } else if (zoom > 1f) {
            c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)?.let { a ->
                val cw = (a.width() / zoom).toInt()
                val ch = (a.height() / zoom).toInt()
                val l = a.centerX() - cw / 2
                val t = a.centerY() - ch / 2
                b.set(CaptureRequest.SCALER_CROP_REGION, Rect(l, t, l + cw, t + ch))
            }
        }

        // Exposure
        if (manual && hasManual) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            if (video) {
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, minOf(exposureNs, 1_000_000_000L / videoFps))
            } else {
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNs)
                b.set(CaptureRequest.SENSOR_FRAME_DURATION, maxOf(exposureNs, 33_333_333L))
            }
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
            val scenes = c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
            when {
                mode == Mode.HDR && !video && has(scenes, CameraMetadata.CONTROL_SCENE_MODE_HDR) -> {
                    b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_USE_SCENE_MODE)
                    b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
                }
                mode == Mode.NIGHT && !video -> {
                    if (has(scenes, CameraMetadata.CONTROL_SCENE_MODE_NIGHT)) {
                        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_USE_SCENE_MODE)
                        b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_NIGHT)
                    } else { // fallback: allow long exposures + brighten
                        c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                            ?.minByOrNull { it.upper }?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
                        c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                            ?.let { b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, maxOf(ev, it.upper / 2)) }
                    }
                }
            }
        }
        if (video) videoRange?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }

        // Focus
        val af = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
        if (manualFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focus)
        } else {
            val m = when {
                video && has(af, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO) -> CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                has(af, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE) -> CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                else -> CameraMetadata.CONTROL_AF_MODE_AUTO
            }
            b.set(CaptureRequest.CONTROL_AF_MODE, m)
        }

        // Tap-to-focus / metering region
        val mr = meter
        if (mr != null) {
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0 && !manualFocus)
                b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(mr))
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0 && !(manual && hasManual))
                b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(mr))
        }

        // White balance preset
        if (awbIdx > 0 && has(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES), awbValues[awbIdx]))
            b.set(CaptureRequest.CONTROL_AWB_MODE, awbValues[awbIdx])

        // Flash (torch is used so exposure can settle before capture / as video light)
        if (hasFlash && (torchOn || (mode == Mode.VIDEO && flashMode == 1)))
            b.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH)

        // Quality (stills only, to keep preview fast)
        if (still) {
            if (has(c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES), CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            if (has(c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES), CameraMetadata.EDGE_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_HIGH_QUALITY)
            // Extra processing quality flags (only when the device offers them)
            if (has(c.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES), CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.HOT_PIXEL_MODE, CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY)
            if (has(c.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES), CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
            if (has(c.get(CameraCharacteristics.SHADING_AVAILABLE_MODES), CameraMetadata.SHADING_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.SHADING_MODE, CameraMetadata.SHADING_MODE_HIGH_QUALITY)
            if (has(c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES), CameraMetadata.TONEMAP_MODE_HIGH_QUALITY))
                b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_HIGH_QUALITY)
        }

        // Stabilization
        if (video && has(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES), CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON))
            b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        else if (has(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION), CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON))
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)
    }

    // ---------- photo / RAW ----------
    private fun setupReaders() {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val js = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width.toLong() * it.height }!!
        jpegReader = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 2).apply {
            setOnImageAvailableListener({ saveJpeg(it) }, handler)
        }
        rawReader = if (hasRaw) {
            val rs = map.getOutputSizes(ImageFormat.RAW_SENSOR).maxByOrNull { it.width.toLong() * it.height }!!
            ImageReader.newInstance(rs.width, rs.height, ImageFormat.RAW_SENSOR, 3).apply {
                setOnImageAvailableListener({ onRaw(it) }, handler)
            }
        } else null
    }

    fun capture() {
        if (mode == Mode.VIDEO) return
        val manualAe = manual && hasManual
        val useFlash = hasFlash && (flashMode == 1 ||
            (flashMode == 0 && !manualAe && aeState == CameraMetadata.CONTROL_AE_STATE_FLASH_REQUIRED))
        if (useFlash) {
            torchOn = true
            refresh()
            handler.postDelayed({ doCapture() }, 700) // let exposure settle under the light
        } else doCapture()
    }

    private fun doCapture() {
        val s = session
        val d = device
        val jr = jpegReader
        if (s == null || d == null || jr == null) {
            if (torchOn) { torchOn = false; refresh() }
            return
        }
        val withRaw = rawEnabled && rawReader != null
        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(jr.surface)
        if (withRaw) b.addTarget(rawReader!!.surface)
        applyParams(b, CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.set(CaptureRequest.JPEG_ORIENTATION, chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90)
        b.set(CaptureRequest.JPEG_QUALITY, 100)
        s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(ss: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                if (torchOn) { torchOn = false; refresh() }
                if (withRaw) {
                    val ts = res.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
                    synchronized(this@CameraController) { results[ts] = res }
                    tryDng(ts)
                }
                onMsg("تم الحفظ ✔")
            }
        }, handler)
    }

    private fun saveJpeg(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
        img.close()
        val id = stamp()
        save("IMG_$id.jpg", "image/jpeg", "Pictures/ProCam", false) { it.write(bytes) }
        if (aiLevel > 0) {
            try {
                val out = Enhancer.enhance(bytes, chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90, aiLevel)
                if (out != null) {
                    save("IMG_${id}_AI.jpg", "image/jpeg", "Pictures/ProCam", false) { it.write(out) }
                    onMsg("تم التحسين الذكي ✨")
                }
            } catch (t: Throwable) { onMsg("تعذر التحسين: ${t.javaClass.simpleName}") }
        }
    }

    private fun onRaw(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        synchronized(this) { rawImages[img.timestamp] = img }
        tryDng(img.timestamp)
    }

    private fun tryDng(ts: Long) {
        val pair = synchronized(this) {
            val i = rawImages[ts]; val r = results[ts]
            if (i != null && r != null) { rawImages.remove(ts); results.remove(ts); i to r } else null
        } ?: return
        val (img, res) = pair
        save("RAW_${stamp()}.dng", "image/x-adobe-dng", "Pictures/ProCam", false) { out ->
            DngCreator(chars, res).use { it.writeImage(out, img) }
        }
        img.close()
    }

    // ---------- video ----------
    fun toggleRecord() {
        try { if (recording) stopRecording() else startRecording() }
        catch (e: Exception) { abortRecorder(); onMsg("فشل التسجيل: ${e.message}"); start() }
    }

    private fun pickVideoConfig() {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(MediaRecorder::class.java)
        videoSize = (if (forceHd) null else sizes.firstOrNull { it.width == 3840 && it.height == 2160 })
            ?: sizes.filter { it.width * 9 == it.height * 16 && it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: sizes.first()
        val minDur = map.getOutputMinFrameDuration(MediaRecorder::class.java, videoSize)
        val maxFps = if (minDur > 0) (1_000_000_000.0 / minDur).toInt() else 30
        val ranges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: emptyArray()
        val r60 = ranges.filter { it.upper == 60 }.maxByOrNull { it.lower }
        videoFps = if (!forceHd && maxFps >= 60 && r60 != null) 60 else 30
        videoRange = if (videoFps == 60) r60 else ranges.filter { it.upper == 30 }.maxByOrNull { it.lower }
    }

    private fun buildRecorder(codec: Int): MediaRecorder {
        @Suppress("DEPRECATION")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(recPfd!!.fileDescriptor)
            r.setVideoEncodingBitRate((videoSize.width.toLong() * videoSize.height * videoFps / 10).toInt())
            r.setVideoFrameRate(videoFps)
            r.setVideoSize(videoSize.width, videoSize.height)
            r.setVideoEncoder(codec)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(256_000)
            r.setAudioSamplingRate(48_000)
            r.setOrientationHint(chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90)
            r.prepare()
        } catch (e: Exception) { r.release(); throw e }
        return r
    }

    private fun startRecording() {
        val d = device ?: return
        val st = tv.surfaceTexture ?: return
        pickVideoConfig()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProCam")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        recPfd = ctx.contentResolver.openFileDescriptor(uri, "w")
        val r = try { buildRecorder(MediaRecorder.VideoEncoder.HEVC) }
        catch (e: Exception) { buildRecorder(MediaRecorder.VideoEncoder.H264) }
        recorder = r
        closeSession()
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val ps = surfaceFor(st)
        targets = listOf(ps, r.surface)
        template = CameraDevice.TEMPLATE_RECORD
        openSession(d, targets) {
            r.start(); markRecording(true)
            onMsg("تسجيل ${videoSize.width}x${videoSize.height} @${videoFps}fps")
        }
    }

    private fun stopRecording(restart: Boolean = true) {
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        try { recorder?.stop() } catch (e: Exception) {}
        recorder?.release(); recorder = null
        recPfd?.close(); recPfd = null
        markRecording(false)
        onMsg("تم حفظ الفيديو ✔")
        if (restart) start()
    }

    // ---------- storage ----------
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    private fun save(name: String, mime: String, rel: String, video: Boolean, write: (OutputStream) -> Unit) {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
        }
        val col = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = ctx.contentResolver.insert(col, cv) ?: return
        ctx.contentResolver.openOutputStream(uri)?.use(write)
    }
}
