package com.example.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

/** Rule-of-thirds grid + horizon level line. Does not intercept touches. */
class OverlayView(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    var showGrid = false
    var roll = 0f
    var upright = true
    private val grid = Paint().apply { color = 0x66FFFFFF; strokeWidth = 2f; isAntiAlias = true }
    private val lvl = Paint().apply { strokeWidth = 4f; isAntiAlias = true }

    override fun onDraw(c: Canvas) {
        if (!showGrid) return
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            c.drawLine(w * i / 3, 0f, w * i / 3, h, grid)
            c.drawLine(0f, h * i / 3, w, h * i / 3, grid)
        }
        if (upright) {
            val ok = abs(roll) < 1f
            lvl.color = if (ok) 0xFFFFB300.toInt() else 0xAAFFFFFF.toInt()
            c.save()
            c.rotate(roll, w / 2, h / 2)
            val half = if (ok) w * 0.18f else w * 0.12f
            c.drawLine(w / 2 - half, h / 2, w / 2 + half, h / 2, lvl)
            c.restore()
        }
    }
}
